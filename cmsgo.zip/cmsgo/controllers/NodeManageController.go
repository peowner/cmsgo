package controllers

import (
	"cmsgo/models"
	"fmt"
	"strconv"

	"cmsgo/models/node"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
)

type NodeManageController struct {
	beego.Controller
}

//分页处理

func (this *NodeManageController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "Id"
	}
	nodes, count := node.GetNodelist(page, page_size, sort)
	if len(nodes) < 1 {
		nodes = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &nodes}
	this.ServeJSON()
	return
}

func (this *NodeManageController) List() {
	this.Data["Nodes"] = node.All()
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "listNode.tpl"
}

//新建频道

func (this *NodeManageController) DoAdd() {
	nodeName := this.GetString("NodeName")
	orderId, _ := this.GetInt("OrderId")
	siteId, _ := this.GetInt("SiteId")
	isUsed, _ := this.GetInt("IsUsed")
	n := &models.Node{NodeName: nodeName, SiteId: siteId, OrderId: orderId, IsUsed: isUsed}
	_, err := node.Save(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/nodeManage", 302)
}

//修改频道
//显示当前修改频道信息

func (this *NodeManageController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	n := node.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such Node")
		return
	}

	this.Data["Node"] = n

	this.TplName = "editNode.tpl"
}

//保存修该后频道信息

func (this *NodeManageController) DoEdit() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param id fail")
		return
	}

	n := node.OneById(id)
	if n == nil {
		this.Ctx.WriteString("no such node")
		return
	}
	siteId, _ := this.GetInt("SiteId")
	nodeName := this.GetString("NodeName")
	orderId, _ := this.GetInt("OrderId")
	isUsed, _ := this.GetInt("IsUsed")

	n.NodeName = nodeName
	n.SiteId = siteId
	n.OrderId = orderId
	n.IsUsed = isUsed
	err = node.Update(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/nodeManage", 302)

}

//删除频道

func (this *NodeManageController) DoDel() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	n := node.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such node")
		return
	}

	if n.IsUsed == 1 {

		this.Ctx.WriteString("不能删除正在使用的频道!")
		return

	}

	err = node.Del(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除频道成功！")

	}

	this.Redirect("/nodeManage", 302)

}
