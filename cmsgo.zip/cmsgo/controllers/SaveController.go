package controllers

import (
	//"cmsgo/models"
	"github.com/astaxie/beego"
	//	"github.com/astaxie/beego/orm"
)

type SaveController struct {
	beego.Controller
}

func (this *SaveController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "order.tpl"
}

func (this *SaveController) Post() {

	beego.Info("开始保存订报信息--------------！")

}
