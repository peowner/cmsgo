package controllers

import (
	"fmt"

	"github.com/astaxie/beego"
)

type SpecificListPubController struct {
	beego.Controller
}

func (this *SpecificListPubController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "creatImage.tpl"
	id := this.Ctx.Input.Param(":id")
	fmt.Println("获得的专题id----------" + id)
}
