package controllers

import (
	"cmsgo/models"
	"cmsgo/models/imagemeta"
	"cmsgo/models/publib"
	"cmsgo/models/spelib"
	//"encoding/json"
	"cmsgo/models/imggroup"
	"fmt"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	//	"github.com/ulricqin/goutils/filetool"
	"strconv"
	"time"
)

const (
	IMGGROUP_DIR = "static/upload/imggroup"
)

type ImgGroupPubController struct {
	beego.Controller
}

func (this *ImgGroupPubController) Get() {
	this.TplName = "creatImgGroup.tpl"
}

//分页处理
func (this *ImgGroupPubController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	imggroups, count := imggroup.GetImgGrouplist(page, page_size, sort)
	if len(imggroups) < 1 {
		imggroups = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &imggroups}
	this.ServeJSON()
	return
}

//新建组图分类
func (this *ImgGroupPubController) Add() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["userinfo"] = userinfo

	this.TplName = "addImgGroup.tpl"
}

//保存新建分类
func (this *ImgGroupPubController) DoAdd() {
	title := this.GetString("Title")
	pubTimeStr := this.GetString("PubTime")
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	readCount, _ := this.GetInt("ReadCount")
	publisher := this.GetString("Publisher")
	var isPublish = 0
	var total = 0
	var pubtype = 7
	s := &models.ImgGroup{Title: title, Publisher: publisher, IsPublish: isPublish, PubTime: pubTime, ReadCount: readCount, Total: total, PubType: pubtype}
	_, err := imggroup.Save(s)
	if err != nil {
		this.Ctx.WriteString(err.Error())

		return
	}
	this.Redirect("/imgGroupPub", 302)
}

//修改
func (this *ImgGroupPubController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	s := imggroup.OneById(int64(id))
	if s == nil {
		this.Ctx.WriteString("no such imggroup")
		return
	}

	this.Data["imgs"] = s

	this.TplName = "editImgGroup.tpl"
}

//保存修改
func (this *ImgGroupPubController) DoEdit() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	s := imggroup.OneById(id)
	if s == nil {
		this.Ctx.WriteString("no such imgGroup")
		return
	}
	title := this.GetString("Title")
	isPublish, _ := this.GetInt("IsPublish")
	pubTimeStr := this.GetString("PubTime")
	if pubTimeStr == "" {
		this.Ctx.WriteString("发布时间不能为空,请重新选择发布时间!")
		return
	}
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	readCount, _ := this.GetInt("ReadCount")
	total, _ := this.GetInt("Total")
	s.Title = title
	s.IsPublish = isPublish
	s.PubTime = pubTime
	s.ReadCount = readCount
	s.Total = total
	err = imggroup.Update(s)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/imgGroupPub", 302)
}

//删除组图
func (this *ImgGroupPubController) Del() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	s := imggroup.OneById(int64(id))
	if s == nil {
		this.Ctx.WriteString("no such imggroup")
		return
	}
	if s.IsPublish == 1 {

		this.Ctx.WriteString("不能删除已经发布的组图！")
		return

	}
	err = imggroup.Del(s)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除组图成功！")

	}

	this.Redirect("/imgGroupPub", 302)

}

//发布组图
func (this *ImgGroupPubController) Publish() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := imggroup.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such imgGroup")
		return
	}

	if f.IsPublish == 1 {

		this.Ctx.WriteString("组图已经发布!")
		return
	}
	this.Data["Imgs"] = f

	this.TplName = "publishImgGroup.tpl"
}

//保存发布
func (this *ImgGroupPubController) DoPublish() {

	id, _ := this.GetInt64("Id")
	if id == 0 {
		this.Ctx.WriteString("get Id  fail!")
		return
	}
	f := imggroup.OneById(id)
	if f == nil {
		this.Ctx.WriteString("no such imgGroup")
		return
	}

	nodeId, _ := this.GetInt("NodeId")
	if nodeId == 0 {
		this.Ctx.WriteString("get nodeId  fail!")
		return
	}
	siteId, _ := this.GetInt("SiteId")
	if siteId == 0 {
		this.Ctx.WriteString("get siteId fail !")
		return
	}

	var SpeId int64

	checkValue, _ := this.GetInt("isPubSpe")

	if checkValue == 1 {

		SpeId, _ = this.GetInt64("SpeId")

		if SpeId == 0 {

			this.Ctx.WriteString("get speId fail !")
			return
		}

	}
	//组图，发布类型为7
	var pubType = 7
	var orderId int64 = 0

	//保存到发布库
	p := &models.Publib{PubType: pubType, MetaId: id, OrderId: orderId, NodeId: nodeId, SiteId: siteId}
	_, err := publib.Save(p)

	if err == nil {

		fmt.Println("发布单张图片到发布库成功！")

	}
	//根据复选框的值，判断是否发布到专题库
	//保存到专题库

	if checkValue == 1 {
		s := &models.Spelib{SpecificId: SpeId, OrderId: orderId, ItemType: pubType, MetaId: id, SiteId: siteId, NodeId: nodeId}
		_, e := spelib.Save(s)

		if e == nil {

			fmt.Println("发布组图到专题库成功！")
		}

	}

	//同时更新幻灯图为已发布状态
	f.IsPublish = 1

	er := imggroup.Update(f)

	if er == nil {

		fmt.Println("组图发布成功！")

	}
	this.Redirect("/imgGroupPub", 302)
}

//添加单张图片
func (this *ImgGroupPubController) AddImgToGroup() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := imggroup.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such imgGroup")
		return
	}
	this.Data["Imgs"] = f

	this.TplName = "addImgToGroup.tpl"

}

//保存添加结果
func (this *ImgGroupPubController) DoAddImgToGroup() {
	groupId, _ := this.GetInt64("GroupId")
	imgUrl := this.GetString("ImgUrl")
	imgText := this.GetString("ImgText")
	title := this.GetString("Title")
	pubTimeStr := this.GetString("PubTime")
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	readCount, _ := this.GetInt("ReadCount")
	author := this.GetString("Author")
	source := this.GetString("Source")
	isPublish := 0
	publisher := ""

	s := &models.ImageMeta{Title: title, Publisher: publisher, GroupId: groupId, ImgUrl: imgUrl, ImgText: imgText, IsPublish: isPublish, PubTime: pubTime, ReadCount: readCount, Source: source, Author: author}
	_, e := imagemeta.Save(s)
	if e != nil {
		this.Ctx.WriteString(e.Error())

		return
	}
	i := imggroup.OneById(groupId)
	var total int = i.Total
	total = total + 1
	i.Total = total
	err := imggroup.Update(i)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	this.Redirect("/imgGroupPub", 302)

}
