package controllers

import (
	"cmsgo/models"
	"cmsgo/models/flash"
	"cmsgo/models/flashpublish"
	"cmsgo/models/spelib"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"github.com/ulricqin/goutils/filetool"
)

const (
	FLASH_IMG_DIR = "static/upload"
)

type FlashImgUrl struct {
	ImgUrl string
}

type FlashPubController struct {
	beego.Controller
}

func (this *FlashPubController) List() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["Flashes"] = flash.All()
	this.TplName = "creatFlash.tpl"
}

func (this *FlashPubController) Add() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["userinfo"] = userinfo
	this.TplName = "addFlash.tpl"
}

//分页处理

func (this *FlashPubController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	flashes, count := flash.GetFlashlist(page, page_size, sort)
	if len(flashes) < 1 {
		flashes = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &flashes}
	this.ServeJSON()
	return

}

//保存上传幻灯图片
func (this *FlashPubController) DoUpload() {
	var imgPath string
	imgPaths := []FlashImgUrl{}
	img := FlashImgUrl{}

	_, header, err := this.GetFile("ImgPath")
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	ext := filetool.Ext(header.Filename)
	imgPath = fmt.Sprintf("%s/%d%s", FLASH_IMG_DIR, time.Now().Unix(), ext)
	img.ImgUrl = imgPath
	imgPaths = append(imgPaths, img)
	result, err := json.Marshal(img)
	this.Ctx.WriteString(string(result))
	fmt.Println("输出的图片路径json-----" + string(result))
	fmt.Println("开始保存幻灯图片")
	filetool.InsureDir(FLASH_IMG_DIR)

	err = this.SaveToFile("ImgPath", imgPath)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

}

//保存新建幻灯图片
func (this *FlashPubController) DoAdd() {
	Title := this.GetString("Title")
	fmt.Println("titel-----" + Title)
	Author := this.GetString("Author")
	fmt.Println("author-----" + Author)
	Source := this.GetString("Source")
	fmt.Println("source" + Source)
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	imgUrl := this.GetString("ImgUrl")
	fmt.Println("imgUrl------" + imgUrl)
	imgText := this.GetString("ImgText")
	fmt.Println("imgText" + imgText)
	publisher := this.GetString("Publisher")
	fmt.Println("publisher-----" + publisher)
	var IsPublish = 0
	var readCount int64
	f := &models.Flash{Title: Title, Author: Author, Publisher: publisher, Source: Source, ImgUrl: imgUrl, ImgText: imgText,
		IsPublish: IsPublish, PubTime: pubTime, ReadCount: readCount}
	_, err := flash.Save(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())

		return
	}
	this.Redirect("/flashPub", 302)
}

//修改频道
//显示当前修改频道信息

func (this *FlashPubController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	f := flash.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}

	this.Data["FlashImg"] = f

	this.TplName = "editFlash.tpl"
}

//保存修该后频道信息

func (this *FlashPubController) DoEdit() {
	id, _ := this.GetInt64("Id")
	if id == 0 {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	f := flash.OneById(id)
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}
	title := this.GetString("Title")
	fmt.Println("titel-----" + title)
	author := this.GetString("Author")
	fmt.Println("author-----" + author)
	Source := this.GetString("Source")
	fmt.Println("source" + Source)
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	fmt.Println("pubTime-----" + pubTimeStr)
	imgUrl := this.GetString("ImgUrl")
	fmt.Println("imgUrl------" + imgUrl)
	imgText := this.GetString("ImgText")
	fmt.Println("imgText" + imgText)
	publisher := this.GetString("Publisher")
	fmt.Println("publisher-----" + publisher)
	IsPublish, _ := this.GetInt("IsPublish")
	readCount, _ := this.GetInt64("ReadCount")
	f.Title = title
	f.Author = author
	f.Source = Source
	f.PubTime = pubTime
	f.ImgUrl = imgUrl
	f.ImgText = imgText
	f.Publisher = publisher
	f.IsPublish = IsPublish
	f.ReadCount = readCount
	err := flash.Update(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/flashPub", 302)

}

func (this *FlashPubController) DoDel() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := flash.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}

	if f.IsPublish == 1 {

		this.Ctx.WriteString("不能删除已经发布的幻灯图片!")
		return

	}

	err = flash.Del(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除幻灯图片成功！")

	}

	this.Redirect("/flashPub", 302)

}

//发布幻灯图片
func (this *FlashPubController) Publish() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := flash.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}

	if f.IsPublish == 1 {

		this.Ctx.WriteString("幻灯图片已经发布!")
		return
	}
	this.Data["FlashImg"] = f

	this.TplName = "publishFlash.tpl"

}

//保存发布幻灯图片,可以同时发布到频道和专题库中
func (this *FlashPubController) DoPublish() {
	id, _ := this.GetInt64("Id")
	if id == 0 {
		this.Ctx.WriteString("get Id  fail!")
		return
	}
	f := flash.OneById(id)
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}

	nodeId, _ := this.GetInt("NodeId")
	if nodeId == 0 {
		this.Ctx.WriteString("get nodeId  fail!")
		return
	}
	siteId, _ := this.GetInt("SiteId")
	if siteId == 0 {
		this.Ctx.WriteString("get siteId fail !")
		return
	}

	//获取是否发布到专题库复选框的值

	var SpeId int64

	checkValue, _ := this.GetInt("isPubSpe")

	if checkValue == 1 {

		SpeId, _ = this.GetInt64("SpeId")

		if SpeId == 0 {

			this.Ctx.WriteString("get speId fail !")
			return
		}

	}
	//幻灯图片，发布类型为1
	var pubType = 1
	var orderId int64 = 0

	//保存到发布库
	p := &models.FlashPublib{PubType: pubType, MetaId: id, OrderId: orderId, NodeId: nodeId, SiteId: siteId}
	_, err := flashpublish.Save(p)

	if err == nil {

		fmt.Println("发布幻灯图片到flash发布库成功！")

	}
	//根据复选框的值，判断是否发布到专题库
	//保存到专题库

	if checkValue == 1 {
		s := &models.Spelib{SpecificId: SpeId, OrderId: orderId, ItemType: pubType, MetaId: id, SiteId: siteId, NodeId: nodeId}
		_, e := spelib.Save(s)

		if e == nil {

			fmt.Println("发布flash到专题库成功！")
		}

	}

	//同时更新幻灯图为已发布状态
	f.IsPublish = 1

	er := flash.Update(f)

	if er == nil {

		fmt.Println("幻灯图发布成功！")

	}
	this.Redirect("/flashPub", 302)
}
