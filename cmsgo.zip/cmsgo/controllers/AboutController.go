//用户中心
//关于我们
package controllers

import (
	"cmsgo/models"
	"cmsgo/models/about"
	"fmt"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	//	"github.com/ulricqin/goutils/filetool"
	"strconv"
	//	"time"
)

type AboutController struct {
	beego.Controller
}

//提供给客户端关于我们信息
func (this *AboutController) AboutUs() {

	abouts, _ := about.GetAboutList(1, 1, "Id")

	this.Data["About"] = &abouts[0]

	this.TplName = "about.tpl"
}

//列表
func (this *AboutController) Get() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.TplName = "listAbout.tpl"
}

//分页
func (this *AboutController) AboutList() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	ord := this.GetString("order")
	if len(ord) > 0 {
		if ord == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "Id"
	}
	abouts, count := about.GetAboutList(page, page_size, sort)
	if len(abouts) < 1 {
		abouts = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &abouts}
	this.ServeJSON()
	return
}

//新建关于我们
func (this *AboutController) AboutAdd() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.TplName = "addAbout.tpl"
}

//保存新建活动
func (this *AboutController) AboutDoAdd() {
	title := this.GetString("Title")
	content := this.GetString("Content")
	n := &models.About{Title: title, Content: content}
	_, err := about.Save(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/aboutMan", 302)

}

//修改活动
func (this *AboutController) AboutEdit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	n := about.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such about")
		return
	}

	this.Data["Actions"] = n

	this.TplName = "editAbout.tpl"

}

//保存修改活动
func (this *AboutController) AboutDoEdit() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param id fail")
		return
	}

	n := about.OneById(id)
	if n == nil {
		this.Ctx.WriteString("no such about!")
		return
	}
	title := this.GetString("Title")
	content := this.GetString("Content")
	n.Title = title
	n.Content = content
	err = about.Update(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/aboutMan", 302)

}

//删除关于我们
func (this *AboutController) AboutDel() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	n := about.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such about")
		return
	}

	err = about.Del(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除关于我们成功！")

	}

	this.Redirect("/aboutMan", 302)
}
