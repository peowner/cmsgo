package controllers

import (
	"cmsgo/models"
	"cmsgo/models/node"
	"fmt"

	"github.com/astaxie/beego"
)

type NodeListController struct {
	beego.Controller
}

func (this *NodeListController) Get() {
	var nodes []*models.Node
	node.Nodes().All(&nodes)
	fmt.Println("输出给客户端的json数据------")
	this.Data["json"] = nodes
	this.ServeJSON()

}

//输出符合zTree要求的json数据

func (this *NodeListController) Post() {
	var nodes []*models.Node
	node.Nodes().All(&nodes)
	fmt.Println("输出给客户端的json数据------")
	this.Data["json"] = nodes
	this.ServeJSON()

}
