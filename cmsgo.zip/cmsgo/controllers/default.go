package controllers

import (
	"github.com/astaxie/beego"
)

//type MainController struct {
//	beego.Controller
//}
type CommonController struct {
	beego.Controller
	Templatetype string //ui template type
}

func (this *MainController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "index.tpl"
}
