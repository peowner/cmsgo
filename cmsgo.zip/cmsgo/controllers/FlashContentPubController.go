package controllers

import (
	"github.com/astaxie/beego"
)

type FlashContentPubController struct {
	beego.Controller
}

func (this *FlashContentPubController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "creatImage.tpl"
}
