package controllers

import (
	"cmsgo/models"
	"fmt"
	"strconv"

	"cmsgo/models/site"

	"github.com/astaxie/beego/orm"

	"github.com/astaxie/beego"
)

type SiteManageController struct {
	beego.Controller
}

//显示所有站点信息

func (this *SiteManageController) Add() {
	this.Data["Sites"] = site.All()
	this.TplName = "siteManage.tpl"
}

func (this *SiteManageController) AddSite() {
	this.TplName = "addSite.tpl"
}

//分页处理

func (this *SiteManageController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "Id"
	}
	sites, count := site.GetSitelist(page, page_size, sort)
	if len(sites) < 1 {
		sites = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &sites}
	this.ServeJSON()
	return
}

//新建站点业务流程

func (this *SiteManageController) DoAdd() {
	siteName := this.GetString("SiteName")
	isUsed, _ := this.GetInt("IsUsed")
	if isUsed == 0 || siteName == "" {
		this.Ctx.WriteString("siteName || isUsed  is illegal")
		return
	}

	s := &models.Site{SiteName: siteName, IsUsed: isUsed}
	_, err := site.Save(s)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	this.Redirect("/siteManage", 302)
}

//修改站点业务流程

func (this *SiteManageController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	s := site.OneById(int64(id))
	if s == nil {
		this.Ctx.WriteString("no such site")
		return
	}

	this.Data["Site"] = s

	this.TplName = "editSite.tpl"
}

//保存修改信息业务流程

func (this *SiteManageController) DoEdit() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param id fail")
		return
	}

	s := site.OneById(id)
	if s == nil {
		this.Ctx.WriteString("no such site")
		return
	}

	siteName := this.GetString("SiteName")
	isUsed, _ := this.GetInt("IsUsed")
	if siteName == "" {
		this.Ctx.WriteString(" siteName is blank")
		return
	}

	s.SiteName = siteName
	s.IsUsed = isUsed

	err = site.Update(s)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/siteManage", 302)
}

//删除站点业务流程

func (this *SiteManageController) Del() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	s := site.OneById(int64(id))
	if s == nil {
		this.Ctx.WriteString("no such site")
		return
	}

	if s.IsUsed == 1 {

		this.Ctx.WriteString("不能删除正在使用的站点！")
		return

	}

	err = site.Del(s)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除站点成功！")

	}

	this.Redirect("/siteManage", 302)
}
