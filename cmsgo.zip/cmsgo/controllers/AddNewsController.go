package controllers

import (
	"cmsgo/models"
	"cmsgo/models/news"
	"cmsgo/models/publib"
	"cmsgo/models/spelib"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"github.com/ulricqin/goutils/filetool"
)

const (
	NEWS_IMG_DIR = "static/upload/news"
)

type NewsImgUrl struct {
	ImgUrl string
}

type AddNewsController struct {
	beego.Controller
}

func (this *AddNewsController) Get() {
	this.TplName = "creatNews.tpl"
}

//分页处理

func (this *AddNewsController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	newses, count := news.GetNewslist(page, page_size, sort)
	if len(newses) < 1 {
		newses = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &newses}
	this.ServeJSON()
	return

}

//新建新闻

func (this *AddNewsController) Add() {

	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["userinfo"] = userinfo

	this.TplName = "addNews.tpl"

}

//保存标题图片
func (this *AddNewsController) DoUpload() {
	var imgPath string
	imgPaths := []NewsImgUrl{}
	img := NewsImgUrl{}

	_, header, err := this.GetFile("ImgPath")
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	ext := filetool.Ext(header.Filename)
	imgPath = fmt.Sprintf("%s/%d%s", NEWS_IMG_DIR, time.Now().Unix(), ext)
	img.ImgUrl = imgPath
	imgPaths = append(imgPaths, img)
	result, err := json.Marshal(img)
	this.Ctx.WriteString(string(result))
	fmt.Println("输出的图片路径json-----" + string(result))
	fmt.Println("开始保存新闻标题图片")
	filetool.InsureDir(NEWS_IMG_DIR)

	err = this.SaveToFile("ImgPath", imgPath)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

}

func (this *AddNewsController) DoAdd() {
	title := this.GetString("Title")
	subject := this.GetString("Subject")
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	author := this.GetString("Author")
	fmt.Println("author-----" + author)
	source := this.GetString("Source")
	fmt.Println("source" + source)
	imgUrl := this.GetString("ImgUrl")
	fmt.Println("imgUrl------" + imgUrl)
	content := this.GetString("Content")
	var isPublish = 0
	var readCount = 0
	var publisher = "用户"
	var pubtype = 4
	n := &models.News{Title: title, Subject: subject, PubTime: pubTime, Author: author, Source: source, TitleImg: imgUrl, Content: content, IsPublish: isPublish, ReadCount: int64(readCount), Publisher: publisher, PubType: pubtype}
	_, err := news.Save(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/newsPub", 302)
}

//修改频道
//显示当前修改频道信息

func (this *AddNewsController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	n := news.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such News")
		return
	}

	this.Data["News"] = n

	this.TplName = "editNews.tpl"
}

//保存修该后频道信息

func (this *AddNewsController) DoEdit() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param id fail")
		return
	}

	n := news.OneById(id)
	if n == nil {
		this.Ctx.WriteString("no such news!")
		return
	}
	title := this.GetString("Title")
	subject := this.GetString("Subject")
	author := this.GetString("Author")
	source := this.GetString("Source")
	isPublish, _ := this.GetInt("IsPublish")
	titleImg := this.GetString("ImgUrl")
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	publisher := this.GetString("Publisher")
	content := this.GetString("Content")
	readCount, _ := this.GetInt64("ReadCount")
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	n.Title = title
	n.Subject = subject
	n.Author = author
	n.Source = source
	n.IsPublish = isPublish
	n.TitleImg = titleImg
	n.PubTime = pubTime
	n.Publisher = publisher
	n.ReadCount = readCount
	n.Content = content
	err = news.Update(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/newsPub", 302)

}

//撤回
func (this *AddNewsController) Revoke() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	n := news.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such News")
		return
	}
	if n.IsPublish == 0 {
		this.Ctx.WriteString("该新闻没有发布，不需要撤回！")
		return
	}
	n.IsPublish = 0
	err = news.Update(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/newsPub", 302)

}

//删除

func (this *AddNewsController) Del() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	n := news.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such node")
		return
	}

	if n.IsPublish == 1 {
		this.Ctx.WriteString("不能删除已经发布的新闻!")
		return
	}

	err = news.Del(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除新闻成功！")

	}

	this.Redirect("/newsPub", 302)

}

//发布新闻
func (this *AddNewsController) Publish() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	n := news.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such News")
		return
	}
	if n.IsPublish == 1 {
		this.Ctx.WriteString("该新闻已经发布！")
		return
	}

	this.Data["News"] = n

	this.TplName = "publishNews.tpl"
}

//保存发布新闻
func (this *AddNewsController) DoPublish() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param Id fail")
		return
	}
	n := news.OneById(id)
	if n == nil {
		this.Ctx.WriteString("no such News")
		return
	}
	nodeId, _ := this.GetInt("NodeId")
	if nodeId == 0 {
		this.Ctx.WriteString("get nodeId  fail!")
		return
	}
	siteId, _ := this.GetInt("SiteId")
	if siteId == 0 {
		this.Ctx.WriteString("get siteId fail !")
		return
	}

	//获取是否发布到专题库复选框的值

	var SpeId int64

	checkValue, _ := this.GetInt("isPubSpe")

	if checkValue == 1 {

		SpeId, _ = this.GetInt64("SpeId")

		if SpeId == 0 {

			this.Ctx.WriteString("get speId fail !")
			return
		}

	}
	//幻灯图片，发布类型为1
	var pubType = 4
	var orderId int64 = 0

	//保存到发布库
	p := &models.Publib{PubType: pubType, MetaId: id, OrderId: orderId, NodeId: nodeId, SiteId: siteId}
	_, er := publib.Save(p)

	if er == nil {

		fmt.Println("发布新闻到发布库成功！")

	}

	//根据复选框的值，判断是否发布到专题库
	//保存到专题库

	if checkValue == 1 {
		s := &models.Spelib{SpecificId: SpeId, OrderId: orderId, ItemType: pubType, MetaId: id, SiteId: siteId, NodeId: nodeId}
		_, e := spelib.Save(s)

		if e == nil {

			fmt.Println("发布新闻到专题库成功！")
		}

	}

	//同时更新新闻为已发布状态
	n.IsPublish = 1

	erre := news.Update(n)

	if erre == nil {

		fmt.Println("新闻发布成功！")

	}
	this.Redirect("/newsPub", 302)

}
