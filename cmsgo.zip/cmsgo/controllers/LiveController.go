package controllers

import (
	"cmsgo/models"
	"cmsgo/models/live"
	"cmsgo/models/livecontent"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
)

type LiveController struct {
	beego.Controller
}

//直播分页

func (this *LiveController) LiveList() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	ord := this.GetString("order")
	if len(ord) > 0 {
		if ord == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "Id"
	}
	lives, count := live.GetLiveList(page, page_size, sort)
	if len(lives) < 1 {
		lives = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &lives}
	this.ServeJSON()
	return

}

//直播发布
func (this *LiveController) GetLive() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.TplName = "listLive.tpl"
}

//新建直播
func (this *LiveController) AddLive() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.TplName = "addLive.tpl"
}

//保存新建直播
func (this *LiveController) DoAddLive() {
	name := this.GetString("Name")
	subject := this.GetString("Subject")
	liveType, _ := this.GetInt("LiveType")
	titleImg := this.GetString("ImgUrl")
	hostId, _ := this.GetInt64("HostId")
	n := &models.Live{Name: name, Subject: subject, LiveType: liveType, TitleImg: titleImg, HostId: hostId}
	_, err := live.Save(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/liveMan", 302)

}

//直播内容发布

func (this *LiveController) GetLiveContent() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.TplName = "listLiveContent.tpl"
}

//直播内容分页
func (this *LiveController) GetLiveContentList() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	ord := this.GetString("order")
	if len(ord) > 0 {
		if ord == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "Id"
	}
	liveContents, count := livecontent.GetLiveContentList(page, page_size, sort)
	if len(liveContents) < 1 {
		liveContents = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &liveContents}
	this.ServeJSON()
	return

}
