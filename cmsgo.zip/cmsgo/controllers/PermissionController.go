package controllers

import (
	m "cmsgo/models"
	"cmsgo/models/group"
	"cmsgo/models/permission"
	"encoding/json"

	"github.com/astaxie/beego/orm"
)

type PermissionController struct {
	CommonController
}

func (this *PermissionController) Rsp(status bool, str string) {
	this.Data["json"] = &map[string]interface{}{"status": status, "info": str}
	this.ServeJSON()
}

func (this *PermissionController) Index() {
	if this.IsAjax() {
		page, _ := this.GetInt64("page")
		page_size, _ := this.GetInt64("rows")
		sort := this.GetString("sort")
		order := this.GetString("order")
		if len(order) > 0 {
			if order == "desc" {
				sort = "-" + sort
			}
		} else {
			sort = "Id"
		}
		nodes, count := permission.GetPermissionlist(page, page_size, sort)
		for i := 0; i < len(nodes); i++ {
			if nodes[i]["Pid"] != 0 {
				nodes[i]["_parentId"] = nodes[i]["Pid"]
			} else {
				nodes[i]["state"] = "closed"
			}
		}
		if len(nodes) < 1 {
			nodes = []orm.Params{}
		}
		this.Data["json"] = &map[string]interface{}{"total": count, "rows": &nodes}
		this.ServeJSON()
		return
	} else {
		grouplist := group.GroupList()
		b, _ := json.Marshal(grouplist)
		this.Data["grouplist"] = string(b)
		this.TplName = "permission.tpl"
	}

}
func (this *PermissionController) AddAndEdit() {
	n := m.Permission{}
	if err := this.ParseForm(&n); err != nil {
		//handle error
		this.Rsp(false, err.Error())
		return
	}
	var id int64
	var err error
	Nid, _ := this.GetInt64("Id")
	if Nid > 0 {
		id, err = permission.UpdatePermission(&n)
	} else {
		group_id, _ := this.GetInt64("Group_id")
		group := new(m.Group)
		group.Id = group_id
		n.Group = group
		if n.Pid != 0 {
			n1, _ := permission.ReadPermission(n.Pid)
			n.Level = n1.Level + 1
		} else {
			n.Level = 1
		}
		id, err = permission.AddPermission(&n)
	}
	if err == nil && id > 0 {
		this.Rsp(true, "Success")
		return
	} else {
		this.Rsp(false, err.Error())
		return
	}

}

func (this *PermissionController) DelPermission() {
	Id, _ := this.GetInt64("Id")
	status, err := permission.DelPermissionById(Id)
	if err == nil && status > 0 {
		this.Rsp(true, "Success")
		return
	} else {
		this.Rsp(false, err.Error())
		return
	}
}
