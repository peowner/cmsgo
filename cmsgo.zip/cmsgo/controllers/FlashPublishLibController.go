package controllers

import (
	"cmsgo/models/flash"
	"cmsgo/models/flashpublish"
	"fmt"
	"strconv"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
)

type FlashPublishLibController struct {
	beego.Controller
}

func (this *FlashPublishLibController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "flashPublishLib.tpl"
}

//分页处理

func (this *FlashPublishLibController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	flashMetas, count := flashpublish.GetFlashMetalist(page, page_size, sort)
	if len(flashMetas) < 1 {
		flashMetas = []orm.Params{}
	}

	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &flashMetas}
	this.ServeJSON()
	return

}

//撤回
func (this *FlashPublishLibController) Revoke() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	s := flashpublish.OneById(int64(id))
	if s == nil {
		this.Ctx.WriteString("no such meta")
		return
	}
	metaId := s.MetaId

	f := flash.OneById(metaId)

	f.IsPublish = 0

	e := flash.Update(f)

	if e == nil {
		fmt.Println("撤回flash元数据成功！")

	}
	err = flashpublish.Del(s)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除幻灯发布库元数据成功！")

	}

	this.Redirect("/listFlashPublish", 302)

}
