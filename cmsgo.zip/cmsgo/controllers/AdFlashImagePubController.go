package controllers

import (
	"cmsgo/models"
	"cmsgo/models/adflashimg"

	"fmt"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"

	"strconv"
	"time"
)

type AdFlashImagePubController struct {
	beego.Controller
}

func (this *AdFlashImagePubController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "creatadFlashImage.tpl"
}
func (this *AdFlashImagePubController) Add() {
	Id := this.GetString("Glob_node_id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}

	this.Data["NodeId"] = Id
	this.Data["userinfo"] = userinfo

	this.TplName = "addadFlashImage.tpl"
}

//分页处理

func (this *AdFlashImagePubController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "Id"
	}
	images, count := adflashimg.GetAdFlashImagelist(page, page_size, sort)
	if len(images) < 1 {
		images = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &images}
	this.ServeJSON()
	return

}

//保存新建图片
func (this *AdFlashImagePubController) DoAdd() {
	nodeId, _ := this.GetInt64("NodeId")
	Title := this.GetString("Title")
	fmt.Println("titel-----" + Title)
	Author := this.GetString("Author")
	fmt.Println("author-----" + Author)
	Source := this.GetString("Source")
	fmt.Println("source" + Source)
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	imgUrl := this.GetString("ImgUrl")
	fmt.Println("imgUrl------" + imgUrl)
	imgText := this.GetString("ImgText")
	fmt.Println("imgText" + imgText)
	publisher := this.GetString("Publisher")
	fmt.Println("publisher-----" + publisher)
	var IsPublish = 0
	var readCount int64
	i := &models.AdFlashImg{NodeId: nodeId, Title: Title, Author: Author, Publisher: publisher, Source: Source, ImgUrl: imgUrl, ImgText: imgText,
		IsPublish: IsPublish, PubTime: pubTime, ReadCount: readCount}
	_, err := adflashimg.Save(i)
	if err != nil {
		this.Ctx.WriteString(err.Error())

		return
	}
	this.Redirect("/adflashimagePub", 302)
}

//显示修改图片
func (this *AdFlashImagePubController) ShowEdit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	i := adflashimg.OneById(int64(id))
	if i == nil {
		this.Ctx.WriteString("no such image")
		return
	}

	this.Data["adImg"] = i

	this.TplName = "editadFlashImage.tpl"
}

//保存修改

func (this *AdFlashImagePubController) DoEdit() {
	id, _ := this.GetInt64("Id")
	if id == 0 {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	f := adflashimg.OneById(id)
	if f == nil {
		this.Ctx.WriteString("no such image")
		return
	}
	title := this.GetString("Title")
	nodeId, _ := this.GetInt64("NodeId")
	fmt.Println("titel-----" + title)
	author := this.GetString("Author")
	fmt.Println("author-----" + author)
	Source := this.GetString("Source")
	fmt.Println("source" + Source)
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	fmt.Println("pubTime-----" + pubTimeStr)
	imgUrl := this.GetString("ImgUrl")
	fmt.Println("imgUrl------" + imgUrl)
	imgText := this.GetString("ImgText")
	fmt.Println("imgText" + imgText)
	publisher := this.GetString("Publisher")
	fmt.Println("publisher-----" + publisher)
	IsPublish, _ := this.GetInt("IsPublish")
	readCount, _ := this.GetInt64("ReadCount")
	f.Title = title
	f.NodeId = nodeId
	f.Author = author
	f.Source = Source
	f.PubTime = pubTime
	f.ImgUrl = imgUrl
	f.ImgText = imgText
	f.Publisher = publisher
	f.IsPublish = IsPublish
	f.ReadCount = readCount
	err := adflashimg.Update(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/adflashimagePub", 302)

}
func (this *AdFlashImagePubController) DoDel() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := adflashimg.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}

	if f.IsPublish == 1 {

		this.Ctx.WriteString("不能删除已经发布的图片!")
		return

	}

	err = adflashimg.Del(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除图片成功！")

	}
	this.Redirect("/adflashimagePub", 302)

}

//发布图片
func (this *AdFlashImagePubController) Publish() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := adflashimg.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such image")
		return
	}

	if f.IsPublish == 1 {

		this.Ctx.WriteString("图片已经发布!")
		return
	}
	f.IsPublish = 1

	er := adflashimg.Update(f)

	if er == nil {

		fmt.Println("内容广告图发布成功！")

	}
	this.Redirect("/adflashimagePub", 302)

}

//撤回封面广告图
func (this *AdFlashImagePubController) Revoke() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := adflashimg.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such image")
		return
	}

	if f.IsPublish == 0 {

		this.Ctx.WriteString("图片已经撤回!")
		return
	}
	f.IsPublish = 0

	er := adflashimg.Update(f)

	if er == nil {

		fmt.Println("内容广告图撤回成功！")

	}
	this.Redirect("/adflashimagePub", 302)

}
