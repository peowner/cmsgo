package controllers

import (
	"cmsgo/models/spelib"
	"fmt"
	"strconv"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
)

type SpecificLibController struct {
	beego.Controller
}

func (this *SpecificLibController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "spelib.tpl"
}
func (this *SpecificLibController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "Id"
	}
	spelibs, count := spelib.GetSpeliblist(page, page_size, sort)
	if len(spelibs) < 1 {
		spelibs = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &spelibs}
	this.ServeJSON()
	return

}

//专题库中撤回发布，只是将专题库中的元数据记录删除

func (this *SpecificLibController) RevokeSpeLib() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	spe := spelib.OneById(int64(id))

	err1 := spelib.Del(spe)

	if err1 != nil {

		fmt.Println("撤回专题元数据失败！")

		return

	}

	this.Redirect("/specificLib", 302)

}
