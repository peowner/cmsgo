package controllers

import (
	m "cmsgo/models"
	"cmsgo/models/group"
	p "cmsgo/models/user"
	"cmsgo/src"
	"fmt"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/cache"
	"github.com/astaxie/beego/utils/captcha"
)

type MainController struct {
	CommonController
}

var cpt *captcha.Captcha

func init() {
	// use beego cache system store the captcha data
	store := cache.NewMemoryCache()
	cpt = captcha.NewWithFilter("/captcha/", store)
}

type Tree struct {
	Id         int64      `json:"id"`
	Text       string     `json:"text"`
	IconCls    string     `json:"iconCls"`
	Checked    string     `json:"checked"`
	State      string     `json:"state"`
	Children   []Tree     `json:"children"`
	Attributes Attributes `json:"attributes"`
}
type Attributes struct {
	Url   string `json:"url"`
	Price int64  `json:"price"`
}

//首页
func (this *MainController) Index() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	adminuser := beego.AppConfig.String("rbac_admin_user")
	if userinfo.(m.User).Username != adminuser {

		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))

	}
	tree := this.GetTree()
	if this.IsAjax() {
		this.Data["json"] = &tree
		this.ServeJSON()
		return
	} else {
		groups := group.GroupList()
		this.Data["userinfo"] = userinfo
		this.Data["groups"] = groups
		this.Data["tree"] = &tree

		this.TplName = "public/index.tpl"
	}
}

//登录
func (this *MainController) Login() {
	this.TplName = "public/login.tpl"
	isajax := this.GetString("isajax")
	if isajax == "1" {
		username := this.GetString("username")
		password := this.GetString("password")
		//后台验证下验证码
		checkPin := cpt.VerifyReq(this.Ctx.Request)

		if !checkPin {
			this.Ctx.WriteString("验证码输入错误，请重新输入！")
			return
		}

		user, err := src.CheckLogin(username, password)
		fmt.Println("开始检查登录账户-------------")

		if err == nil {
			this.SetSession("userinfo", user)
			fmt.Println("开始设置session-------------")
			accesslist, _ := src.GetAccessList(user.Id)
			this.SetSession("accesslist", accesslist)
			//如果是管理员登录,则重定向到后台管理
			adminuser := beego.AppConfig.String("rbac_admin_user")
			fmt.Println("从配置文件得到的adminuser" + adminuser)
			if user.Username == adminuser {
				m := "m"
				//返回json为管理员信息
				this.Rsp(true, m)
				return
			} else {
				//登录成功后,重定向到业务系统中
				u := "u"
				this.Rsp(true, u)
				return
			}

		} else {
			this.Rsp(false, err.Error())
			return
		}

	}
}

//业务系统入口

func (this *MainController) Work() {
	userinfo := this.GetSession("userinfo")

	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["userinfo"] = userinfo
	this.TplName = "index.tpl"
}

//退出
func (this *MainController) Logout() {
	this.DelSession("userinfo")
	this.Ctx.Redirect(302, "/public/login")
}

//修改密码界面
func (this *MainController) Editpwd() {
	this.TplName = "editPasswd.tpl"
}

//保存修改密码
func (this *MainController) Changepwd() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	oldpassword := this.GetString("oldpassword")
	newpassword := this.GetString("newpassword")
	repeatpassword := this.GetString("repeatpassword")
	if newpassword != repeatpassword {
		this.Rsp(false, "两次输入密码不一致")
	}
	user, err := src.CheckLogin(userinfo.(m.User).Username, oldpassword)
	if err == nil {
		var u m.User
		u.Id = user.Id
		u.Password = newpassword
		id, err := p.UpdateUser(&u)
		if err == nil && id > 0 {
			this.Rsp(true, "密码修改成功")
			return
		} else {
			this.Rsp(false, err.Error())
			return
		}
	}
	this.Rsp(false, "密码有误")

}
