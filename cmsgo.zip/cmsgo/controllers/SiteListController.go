package controllers

import (
	"cmsgo/models"
	"cmsgo/models/site"
	"fmt"

	"github.com/astaxie/beego"
)

type SiteListController struct {
	beego.Controller
}

func (this *SiteListController) Get() {
	var sites []*models.Site
	site.Sites().All(&sites)
	fmt.Println("输出给客户端的json数据------")
	this.Data["json"] = sites
	this.ServeJSON()

}
