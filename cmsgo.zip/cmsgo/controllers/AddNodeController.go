package controllers

import (
	"github.com/astaxie/beego"
)

type AddNodeController struct {
	beego.Controller
}

func (this *AddNodeController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "addNode.tpl"

}
