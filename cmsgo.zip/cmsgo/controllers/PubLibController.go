package controllers

import (
	"cmsgo/models/flash"
	"cmsgo/models/image"
	"cmsgo/models/imggroup"
	"cmsgo/models/news"
	"cmsgo/models/publib"
	"cmsgo/models/specific"
	"cmsgo/models/video"
	"fmt"
	"strconv"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
)

type PubLibController struct {
	beego.Controller
}

func (this *PubLibController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "pubLib.tpl"
}

//分页处理

func (this *PubLibController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	metaes, count := publib.GetMetalist(page, page_size, sort)
	if len(metaes) < 1 {
		metaes = []orm.Params{}
	}

	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &metaes}
	this.ServeJSON()
	return

}

//从发布库撤回
func (this *PubLibController) Revoke() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	s := publib.OneById(int64(id))
	if s == nil {
		this.Ctx.WriteString("no such meta")
		return
	}
	metaId := s.MetaId

	pubType := s.PubType

	switch pubType {
	case 1:
		f := flash.OneById(metaId)
		f.IsPublish = 0
		err := flash.Update(f)
		if err == nil {
			fmt.Println("撤回flash元数据成功！")

		}
	case 2:
		i := image.OneById(metaId)
		i.IsPublish = 0
		err := image.Update(i)
		if err == nil {
			fmt.Println("撤回image元数据成功！")

		}
	case 3:
		v := video.OneById(metaId)
		v.IsPublish = 0
		err := video.Update(v)
		if err == nil {
			fmt.Println("撤回video元数据成功！")

		}
	case 4:
		n := news.OneById(metaId)
		n.IsPublish = 0
		err := news.Update(n)
		if err == nil {
			fmt.Println("撤回news元数据成功！")
		}
	case 6:
		s := specific.OneById(metaId)
		s.IsPublish = 0
		err := specific.Update(s)
		if err == nil {
			fmt.Println("撤回专题元数据成功！")
		}
	case 7:
		s := imggroup.OneById(metaId)
		s.IsPublish = 0
		err := imggroup.Update(s)
		if err == nil {
			fmt.Println("撤回组图元数据成功！")
		}
	default:
		this.Ctx.WriteString("无此元数据！")
		return
	}

	err = publib.Del(s)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除发布库元数据成功！")

	}

	this.Redirect("/pubLib", 302)

}
