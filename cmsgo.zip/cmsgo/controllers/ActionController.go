//交互系统控制器
//报料  订报   活动
package controllers

import (
	"cmsgo/models"
	"cmsgo/models/action"
	"cmsgo/models/order"
	"cmsgo/models/report"
	//	"encoding/json"
	"fmt"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	//	"github.com/ulricqin/goutils/filetool"
	"strconv"
	//	"time"
)

type ActionController struct {
	beego.Controller
}

const (
	REPORT_IMG_DIR = "static/upload/report"
)

//显示给客户端的订报界面
func (this *ActionController) ListOrderApp() {
	this.TplName = "order.tpl"
}

//保存客户端提交订报信息
func (this *ActionController) SaveOrder() {
	name := this.GetString("name")
	number := this.GetString("number")
	address := this.GetString("address")
	time := this.GetString("time")
	var isDone = 0
	f := &models.Order{User: name, Number: number, Address: address, Time: time, IsDone: isDone}
	_, err := order.Save(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())

		return
	}
	this.Ctx.WriteString("订报成功！")

}

//管理端订报管理
func (this *ActionController) ListOrder() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["orders"] = order.All()
	this.TplName = "listOrder.tpl"
}

//处理订报分页
func (this *ActionController) IndexOrder() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	ord := this.GetString("order")
	if len(ord) > 0 {
		if ord == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	orders, count := order.GetOrderList(page, page_size, sort)
	if len(orders) < 1 {
		orders = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &orders}
	this.ServeJSON()
	return

}

//管理端报料管理
func (this *ActionController) ListReport() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["reports"] = report.All()
	this.TplName = "listReport.tpl"
}

//处理报料分页
func (this *ActionController) IndexReport() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	ord := this.GetString("order")
	if len(ord) > 0 {
		if ord == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	reports, count := report.GetReportList(page, page_size, sort)
	if len(reports) < 1 {
		reports = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &reports}
	this.ServeJSON()
	return

}

//删除订报信息
func (this *ActionController) DelOrder() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := order.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such Order")
		return
	}

	if f.IsDone == 1 {
		this.Ctx.WriteString("不能删除已经处理订单！")
		return

	}

	err = order.Del(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除订报成功！")

	}

	this.Redirect("/orderMan", 302)

}

//处理订报信息

func (this *ActionController) DoOrder() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := order.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such Order")
		return
	}

	if f.IsDone == 1 {
		this.Ctx.WriteString("该订单已经处理！")
		return

	}

	f.IsDone = 1
	err1 := order.Update(f)
	if err1 != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/orderMan", 302)

}

//保存客户端提交的爆料信息
func (this *ActionController) SaveReport() {
	name := this.GetString("Name")
	number := this.GetString("Number")
	content := this.GetString("Content")
	var imgPath string
	var isDone = 0
	r := &models.Report{Username: name, Number: number, Content: content, Image: imgPath, IsDone: isDone}
	_, err1 := report.Save(r)
	if err1 != nil {
		this.Ctx.WriteString(err1.Error())
		return
	}
	this.Data["json"] = &map[string]interface{}{"data": "ok"}
	this.ServeJSON()

}

//删除报料
func (this *ActionController) DoDel() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := report.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such Report")
		return
	}

	if f.IsDone == 1 {
		this.Ctx.WriteString("不能删除已经处理报料！")
		return

	}

	err1 := report.Del(f)
	if err1 != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/reportMan", 302)

}

//处理报料
func (this *ActionController) DoPro() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := report.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such Report")
		return
	}

	if f.IsDone == 1 {
		this.Ctx.WriteString("该报料已经处理！")
		return

	}
	f.IsDone = 1
	err1 := report.Update(f)
	if err1 != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/reportMan", 302)
}

//活动列表
func (this *ActionController) ActionIndex() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.TplName = "listAction.tpl"
}

//活动分页
func (this *ActionController) ActionList() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	ord := this.GetString("order")
	if len(ord) > 0 {
		if ord == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	actions, count := action.GetActionList(page, page_size, sort)
	if len(actions) < 1 {
		actions = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &actions}
	this.ServeJSON()
	return
}

//新建活动
func (this *ActionController) ActionAdd() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.TplName = "addAction.tpl"
}

//保存新建活动
func (this *ActionController) ActionDoAdd() {
	name := this.GetString("Name")
	subject := this.GetString("Subject")
	actionType, _ := this.GetInt("ActionType")
	titleImg := this.GetString("ImgUrl")
	content := this.GetString("Content")
	n := &models.Action{Name: name, Subject: subject, ActionType: actionType, TitleImg: titleImg, Content: content}
	_, err := action.Save(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/actionMan", 302)

}

//修改活动
func (this *ActionController) ActionEdit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	n := action.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such Action")
		return
	}

	this.Data["Actions"] = n

	this.TplName = "editAction.tpl"

}

//保存修改活动
func (this *ActionController) ActionDoEdit() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param id fail")
		return
	}

	n := action.OneById(id)
	if n == nil {
		this.Ctx.WriteString("no such action!")
		return
	}
	name := this.GetString("Name")
	subject := this.GetString("Subject")
	actionType, _ := this.GetInt("ActionType")
	titleImg := this.GetString("ImgUrl")
	content := this.GetString("Content")
	n.Name = name
	n.ActionType = actionType
	n.Content = content
	n.Subject = subject
	n.TitleImg = titleImg
	err = action.Update(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/actionMan", 302)

}

//删除活动
func (this *ActionController) ActionDel() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	n := action.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such action")
		return
	}

	err = action.Del(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除活动成功！")

	}

	this.Redirect("/actionMan", 302)
}
