package controllers

import (
	"cmsgo/models"
	"cmsgo/models/suggestion"
	//"encoding/json"

	"fmt"
	"strconv"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
)

type SuggestionController struct {
	beego.Controller
}

//处理客户端提交建议

func (this *SuggestionController) SaveSuggestion() {
	number := this.GetString("Number")
	content := this.GetString("Content")
	var isDone = 0
	f := &models.Suggestion{Number: number, Content: content, IsDone: isDone}
	_, err := suggestion.Save(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	this.Data["json"] = &map[string]interface{}{"data": "ok"}
	this.ServeJSON()
}

//分页
func (this *SuggestionController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	suggestions, count := suggestion.GetSuggestionList(page, page_size, sort)
	if len(suggestions) < 1 {
		suggestions = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &suggestions}
	this.ServeJSON()
	return

}

//列出建议反馈
func (this *SuggestionController) Get() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.TplName = "listSuggestion.tpl"
}

//处理建议
func (this *SuggestionController) Done() {

	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := suggestion.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such Suggestion!")
		return
	}

	if f.IsDone == 1 {
		this.Ctx.WriteString("该建议已经处理！")
		return

	}

	f.IsDone = 1
	err1 := suggestion.Update(f)
	if err1 != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/suggestionMan", 302)

}

//删除建议
func (this *SuggestionController) DoDel() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := suggestion.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such suggestion")
		return
	}

	if f.IsDone == 1 {
		this.Ctx.WriteString("不能删除已经处理建议！")
		return

	}

	err = suggestion.Del(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除建议成功！")

	}

	this.Redirect("/suggestionMan", 302)

}
