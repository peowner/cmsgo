package controllers

import (
	"fmt"

	"github.com/astaxie/beego"
)

type NewsContentPubController struct {
	beego.Controller
}

func (this *NewsContentPubController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "creatImage.tpl"
	id := this.Ctx.Input.Param(":id")
	fmt.Println("获得的普通新闻稿件id----------" + id)
}
