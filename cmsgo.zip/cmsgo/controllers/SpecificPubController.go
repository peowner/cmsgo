package controllers

import (
	"cmsgo/models"
	"cmsgo/models/publib"
	"cmsgo/models/specific"

	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"github.com/ulricqin/goutils/filetool"
)

const (
	ZT_IMG_DIR = "static/specific/upload"
)

type SpecificPubController struct {
	beego.Controller
}

func (this *SpecificPubController) Get() {
	this.Data["Specifics"] = specific.All()
	this.TplName = "creatSpecific.tpl"
}

func (this *SpecificPubController) List() {
	specifics := specific.All()
	fmt.Println("输出给客户端的json数据------")
	this.Data["json"] = specifics
	this.ServeJSON()

}

//分页处理

func (this *SpecificPubController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	specifics, count := specific.GetSpecificlist(page, page_size, sort)
	if len(specifics) < 1 {
		specifics = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &specifics}
	this.ServeJSON()
	return
}

func (this *SpecificPubController) Add() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "addSpecific.tpl"
}
func (this *SpecificPubController) DoAdd() {
	specialTitle := this.GetString("SpecialTitle")
	siteId, _ := this.GetInt("SiteId")
	specialText := this.GetString("SpecialText")
	isPublish, _ := this.GetInt("IsPublish")
	pubTimeStr := this.GetString("PubTime")
	imgUrl := this.GetString("ImgUrl")

	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)

	var pubtype = 6

	readCount, _ := this.GetInt("ReadCount")
	s := &models.Specific{SpecialTitle: specialTitle, SiteId: siteId, SpecialText: specialText,
		IsPublish: isPublish, PubTime: pubTime, ReadCount: readCount, ImgUrl: imgUrl, PubType: pubtype}
	_, err := specific.Save(s)
	if err != nil {
		this.Ctx.WriteString(err.Error())

		return
	}
	this.Redirect("/specificPub", 302)
}

//保存标题图片
func (this *SpecificPubController) DoUpload() {
	var imgPath string
	imgPaths := []FlashImgUrl{}
	img := FlashImgUrl{}

	_, header, err := this.GetFile("ImgPath")
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	ext := filetool.Ext(header.Filename)
	imgPath = fmt.Sprintf("%s/%d%s", ZT_IMG_DIR, time.Now().Unix(), ext)
	img.ImgUrl = imgPath
	imgPaths = append(imgPaths, img)
	result, err := json.Marshal(img)
	this.Ctx.WriteString(string(result))
	fmt.Println("输出的图片路径json-----" + string(result))
	filetool.InsureDir(ZT_IMG_DIR)

	err = this.SaveToFile("ImgPath", imgPath)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

}

func (this *SpecificPubController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	s := specific.OneById(int64(id))
	if s == nil {
		this.Ctx.WriteString("no such specific")
		return
	}

	this.Data["spec"] = s

	this.TplName = "editSpecific.tpl"
}
func (this *SpecificPubController) DoEdit() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	s := specific.OneById(id)
	if s == nil {
		this.Ctx.WriteString("no such flash")
		return
	}
	specialTitle := this.GetString("SpecialTitle")
	siteId, _ := this.GetInt("SiteId")
	specialText := this.GetString("SpecialText")
	isPublish, _ := this.GetInt("IsPublish")
	pubTimeStr := this.GetString("PubTime")
	imgUrl := this.GetString("ImgUrl")

	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)

	readCount, _ := this.GetInt("ReadCount")
	s.SpecialTitle = specialTitle
	s.SiteId = siteId
	s.SpecialText = specialText
	s.IsPublish = isPublish
	s.PubTime = pubTime
	s.ReadCount = readCount
	s.ImgUrl = imgUrl
	err = specific.Update(s)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/specificPub", 302)
}

func (this *SpecificPubController) DoDel() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	s := specific.OneById(int64(id))
	if s == nil {
		this.Ctx.WriteString("no such flash")
		return
	}

	if s.IsPublish == 1 {

		this.Ctx.WriteString("不能删除已经发布的专题！")
		return

	}

	err = specific.Del(s)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除专题成功！")

	}

	this.Redirect("/specificPub", 302)

}

//撤回专题
func (this *SpecificPubController) DoRev() {

	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	s := specific.OneById(id)
	if s == nil {
		this.Ctx.WriteString("无此专题！")
		return
	}
	if s.IsPublish == 0 {

		this.Ctx.WriteString("该专题已经撤回！")
		return

	}
	s.IsPublish = 0
	err = specific.Update(s)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("撤回专题成功！")

	}

	this.Redirect("/specificPub", 302)

}

//发布专题到发布库
func (this *SpecificPubController) Publish() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := specific.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such specific")
		return
	}

	if f.IsPublish == 1 {

		this.Ctx.WriteString("专题已经发布!")
		return
	}
	this.Data["spe"] = f

	this.TplName = "publishSpecific.tpl"

}

//保存发布专题

func (this *SpecificPubController) DoPublish() {

	id, _ := this.GetInt64("Id")
	if id == 0 {
		this.Ctx.WriteString("get Id  fail!")
		return
	}
	f := specific.OneById(id)
	if f == nil {
		this.Ctx.WriteString("no such specific")
		return
	}

	nodeId, _ := this.GetInt("NodeId")
	if nodeId == 0 {
		this.Ctx.WriteString("get nodeId  fail!")
		return
	}
	siteId, _ := this.GetInt("SiteId")
	if siteId == 0 {
		this.Ctx.WriteString("get siteId fail !")
		return
	}
	//专题，发布类型为6
	var pubType = 6
	var orderId int64 = 0

	//保存到发布库
	p := &models.Publib{PubType: pubType, MetaId: id, OrderId: orderId, NodeId: nodeId, SiteId: siteId}
	_, err := publib.Save(p)

	if err == nil {

		fmt.Println("发布专题到发布库成功！")

	}
	//同时更新幻灯图为已发布状态
	f.IsPublish = 1

	er := specific.Update(f)

	if er == nil {

		fmt.Println("专题发布成功！")

	}
	this.Redirect("/specificPub", 302)
}
