package controllers

import (
	. "cmsgo/models"
	"cmsgo/models/action"
	"cmsgo/models/adcontentimg"
	"cmsgo/models/application"
	"cmsgo/models/flash"
	"cmsgo/models/flashpublish"
	"cmsgo/models/image"
	"cmsgo/models/imagemeta"
	"cmsgo/models/imggroup"
	"cmsgo/models/news"
	"cmsgo/models/publib"
	"cmsgo/models/specific"
	"cmsgo/models/spelib"
	"cmsgo/models/video"
	"encoding/json"
	"fmt"
	//	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
)

type ApiInterfaceController struct {
	beego.Controller
}

//分页处理
func (this *ApiInterfaceController) GetNewsList() {
	//翻页的页数
	page, _ := this.GetInt64("page")
	//每次更新的条数
	page_size, _ := this.GetInt64("rows")
	//按照Id反序排列,这样最后添加的内容在最上边显示
	//频道Id
	nodeId, _ := this.GetInt64("NodeId")
	sort := "-Id"
	metaes, _ := publib.ApiMetalist(page, page_size, sort, nodeId)
	if len(metaes) < 1 {
		metaes = []orm.Params{}
	}

	//var NewsMaps map[int]interface{}

	var ret []interface{}

	var Pubtype int64
	var Id int64
	for i := 0; i < len(metaes); i++ {

		for key, value := range metaes[i] {

			if key == "MetaId" {
				Id = value.(int64)
			} else if key == "PubType" {
				Pubtype = value.(int64)
			}

		}
		//根据元数据id和元数据类型，处理返回元数据信息
		MetaMap := publib.GetNewsById(Id, Pubtype)
		ret = append(ret, MetaMap)

	}
	this.Data["json"] = ret

	this.ServeJSON()
}

//根据专题id获得专题列表

func (this *ApiInterfaceController) GetSpeList() {
	//翻页的页数
	page, _ := this.GetInt64("page")
	//每次更新的条数
	page_size, _ := this.GetInt64("rows")
	//按照Id反序排列,这样最后添加的内容在最上边显示
	//频道Id
	SpecificId, _ := this.GetInt64("SpecificId")
	sort := "-Id"
	metaes, _ := spelib.ApiMetalist(page, page_size, sort, SpecificId)
	if len(metaes) < 1 {
		metaes = []orm.Params{}
	}

	//var NewsMaps map[int]interface{}

	var ret []interface{}

	var Pubtype int64
	var Id int64
	for i := 0; i < len(metaes); i++ {

		for key, value := range metaes[i] {

			if key == "MetaId" {
				Id = value.(int64)
			} else if key == "ItemType" {
				Pubtype = value.(int64)
			}

		}
		//根据元数据id和元数据类型，处理返回元数据信息
		MetaMap := spelib.GetSpeById(Id, Pubtype)
		ret = append(ret, MetaMap)

	}
	this.Data["json"] = ret

	this.ServeJSON()
}

//输出发布库元数据json给客户端

func (this *ApiInterfaceController) GetNewsMeta() {
	//翻页的页数
	page, _ := this.GetInt64("page")
	//每次更新的条数
	page_size, _ := this.GetInt64("rows")
	//按照Id反序排列,这样最后添加的内容在最上边显示
	//频道Id
	nodeId, _ := this.GetInt64("NodeId")
	sort := "-Id"
	metaes, _ := publib.ApiMetalist(page, page_size, sort, nodeId)
	if len(metaes) < 1 {
		metaes = []orm.Params{}
	}
	this.Data["json"] = metaes

	this.ServeJSON()

}

//根据Id和PubType 输出对象json

func (this *ApiInterfaceController) GetJsonById() {
	id, _ := this.GetInt64("MetaId")
	pubType, _ := this.GetInt("PubType")
	switch pubType {

	//幻灯图片
	case 1:
		f := flash.OneById(id)
		this.Data["json"] = f
		this.ServeJSON()
	//单张图片
	case 2:
		i := image.OneById(id)
		readCount := i.ReadCount
		i.ReadCount = readCount + 1
		err := image.Update(i)
		if err != nil {
			fmt.Println("更新单图点击量失败！")
			return

		}
		this.Data["json"] = i
		this.ServeJSON()
	//视频
	case 3:
		v := video.OneById(id)
		//更新视频的点击量
		readCount := v.ReadCount
		v.ReadCount = readCount + 1
		err := video.Update(v)
		if err != nil {

			fmt.Println("更新视频点击量失败！")

			return

		}

		this.Data["json"] = v
		this.ServeJSON()
	//普通新闻
	case 4:
		n := news.OneById(id)
		this.Data["json"] = n
		this.ServeJSON()
	//专题
	case 6:
		s := specific.OneById(id)
		//更新专题的点击量

		readCount := s.ReadCount

		s.ReadCount = readCount + 1

		err := specific.Update(s)

		if err != nil {

			fmt.Println("更新专题点击量失败！")

			return

		}
		this.Data["json"] = s
		this.ServeJSON()
	//组图
	case 7:
		imgs := imggroup.OneById(id)
		this.Data["json"] = imgs
		this.ServeJSON()
	default:
		result := "此稿件已经被删除！"
		this.Data["json"] = result
		this.ServeJSON()
	}

}

//按照频道id输出flash图片json
//分页处理
func (this *ApiInterfaceController) GetFlash() {
	//翻页的页数
	page, _ := this.GetInt64("page")
	//每次更新的条数
	page_size, _ := this.GetInt64("rows")
	//按照Id反序排列,这样最后添加的内容在最上边显示
	//频道Id
	nodeId, _ := this.GetInt64("NodeId")
	sort := "-Id"
	metaes, _ := flashpublish.ApiFlashMetalist(page, page_size, sort, nodeId)
	if len(metaes) < 1 {
		metaes = []orm.Params{}
	}
	//本次请求数据条数

	this.Data["json"] = metaes
	this.ServeJSON()
	return

}

//提供给客户端显示启动界面广告图片URL
func (this *ApiInterfaceController) GetWelcomImgUrl() {
	o := orm.NewOrm()
	i := new(AdImage)
	qs := o.QueryTable(i)
	page_size := int64(1)
	sort := "-Id"
	var Adimages []orm.Params
	qs.Limit(page_size, 0).OrderBy(sort).Values(&Adimages, "ImgUrl")
	this.Data["json"] = &Adimages
	this.ServeJSON()
}

//获得应用接口

func (this *ApiInterfaceController) GetApp() {
	apps := application.All()
	result, _ := json.Marshal(apps)
	this.Ctx.WriteString(string(result))

}

//刮刮卡
func (this *ApiInterfaceController) Card() {

	this.TplName = "card.tpl"

}

//大转盘
func (this *ApiInterfaceController) Lottery() {

	this.TplName = "lottery.tpl"
}

//砸金蛋
func (this *ApiInterfaceController) Egg() {

	this.TplName = "egg.tpl"
}

//提供给客户端活动接口
//@page  为当前请求的第一页
//@offset 为基于当前页的偏移量

func (this *ApiInterfaceController) ActionApi() {
	page, _ := this.GetInt64("Page")
	offset, _ := this.GetInt64("OffSet")
	order := "-Id"
	actions, _ := action.GetActionList(page, offset, order)
	if len(actions) < 1 {
		actions = []orm.Params{}
	}
	//fmt.Println("输出给客户端的json数据------")
	this.Data["json"] = actions
	this.ServeJSON()
}

//提供给客户端资讯列表

func (this *ApiInterfaceController) GetInfoList() {
	page, _ := this.GetInt64("Page")
	offset, _ := this.GetInt64("rows")
	order := "-Id"
	info, _ := adcontentimg.GetAdContentImagelist(page, offset, order)
	if len(info) < 1 {
		info = []orm.Params{}
	}
	//fmt.Println("输出给客户端的json数据------")
	this.Data["json"] = info
	this.ServeJSON()

}

//客户端资讯内容发布
func (this *ApiInterfaceController) InfoContentApi() {

	id, _ := this.GetInt64("Id")

	actionMeta := adcontentimg.OneById(id)

	this.Data["Content"] = actionMeta.Content

	this.TplName = "getActionContent.tpl"

}

//提供给客户端活动内容接口

//@Id  根据活动Id获得内容Html

func (this *ApiInterfaceController) ActionContentApi() {

	id, _ := this.GetInt64("Id")

	actionMeta := action.OneById(id)

	this.Data["Content"] = actionMeta.Content

	this.TplName = "getActionContent.tpl"

}

//提供给客户端新闻内容html
func (this *ApiInterfaceController) NewsContentApi() {

	id, _ := this.GetInt64("Id")

	Meta := news.OneById(id)

	//更新新闻的访问量

	count := Meta.ReadCount

	readCount := count + 1

	Meta.ReadCount = readCount

	err := news.Update(Meta)

	if err != nil {

		fmt.Println("更新新闻点击量出错!")

		return

	}

	this.Data["Content"] = Meta.Content

	this.TplName = "getNewsContent.tpl"

}

//提供组图中单张图的json信息
func (this *ApiInterfaceController) GetImgFromGroupById() {

	groupId, _ := this.GetInt64("GroupId")

	//更新组图的点击量

	imgs := imggroup.OneById(groupId)

	readCount := imgs.ReadCount

	imgs.ReadCount = readCount + 1

	err := imggroup.Update(imgs)

	if err != nil {

		fmt.Println("更新组图点击量失败！")

		return

	}

	imggroup, _ := imagemeta.GetImgsFromGrouplist(groupId)

	this.Data["json"] = imggroup

	this.ServeJSON()

}

//客户端提交直播内容
func (this *ApiInterfaceController) LiveContentApi() {

}
