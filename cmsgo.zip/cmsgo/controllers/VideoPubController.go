package controllers

import (
	"cmsgo/models"
	"cmsgo/models/publib"
	"cmsgo/models/spelib"
	"cmsgo/models/video"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"github.com/ulricqin/goutils/filetool"
)

const (
	VIDEO_IMG_DIR = "static/upload/video/imgs"
	VIDEO_DIR     = "static/upload/video"
)

type VideoImgUrl struct {
	ImgUrl string
}
type VideoFileUrl struct {
	VideoUrl string
}

type VideoPubController struct {
	beego.Controller
}

func (this *VideoPubController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "creatVideo.tpl"
}
func (this *VideoPubController) Add() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["userinfo"] = userinfo
	this.TplName = "addVideo.tpl"
}

//分页处理

func (this *VideoPubController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	videoes, count := video.GetVideolist(page, page_size, sort)
	if len(videoes) < 1 {
		videoes = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &videoes}
	this.ServeJSON()
	return

}

//保存上传视频标题图片
func (this *VideoPubController) UploadImg() {
	var imgPath string
	imgPaths := []VideoImgUrl{}
	img := VideoImgUrl{}

	_, header, err := this.GetFile("ImgPath")
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	ext := filetool.Ext(header.Filename)
	imgPath = fmt.Sprintf("%s/%d%s", VIDEO_IMG_DIR, time.Now().Unix(), ext)
	img.ImgUrl = imgPath
	imgPaths = append(imgPaths, img)
	result, err := json.Marshal(img)
	this.Ctx.WriteString(string(result))
	fmt.Println("输出的图片路径json-----" + string(result))
	fmt.Println("开始保存视频标题图片")
	filetool.InsureDir(VIDEO_IMG_DIR)

	err = this.SaveToFile("ImgPath", imgPath)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

}

//保存上传视频文件
//保存上传视频标题图片
func (this *VideoPubController) UploadVideo() {
	var videoPath string
	videoPaths := []VideoFileUrl{}
	v := VideoFileUrl{}

	_, header, err := this.GetFile("VideoPath")
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	ext := filetool.Ext(header.Filename)
	videoPath = fmt.Sprintf("%s/%d%s", VIDEO_DIR, time.Now().Unix(), ext)
	v.VideoUrl = videoPath
	videoPaths = append(videoPaths, v)
	result, err := json.Marshal(v)
	this.Ctx.WriteString(string(result))
	fmt.Println("输出的图片路径json-----" + string(result))
	fmt.Println("开始保存幻灯图片")
	filetool.InsureDir(VIDEO_DIR)

	err = this.SaveToFile("VideoPath", videoPath)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

}

//新建视频保存
func (this *VideoPubController) DoAdd() {
	Title := this.GetString("Title")
	fmt.Println("titel-----" + Title)
	Author := this.GetString("Author")
	fmt.Println("author-----" + Author)
	Source := this.GetString("Source")
	fmt.Println("source" + Source)
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	imgUrl := this.GetString("ImgUrl")
	fmt.Println("imgUrl------" + imgUrl)
	videoUrl := this.GetString("VideoUrl")
	videoText := this.GetString("VideoText")
	publisher := "用户"
	var isPublish = 0
	readCount := int64(0)
	var pubtype = 3
	v := &models.Video{Title: Title, Author: Author, Publisher: publisher, Source: Source, TitleImg: imgUrl, VideoText: videoText,
		IsPublish: isPublish, PubTime: pubTime, VideoUrl: videoUrl, ReadCount: readCount, PubType: pubtype}
	_, err := video.Save(v)
	if err != nil {
		this.Ctx.WriteString(err.Error())

		return
	}
	this.Redirect("/videoPub", 302)
}
func (this *VideoPubController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	f := video.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such video")
		return
	}

	this.Data["v"] = f

	this.TplName = "editVideo.tpl"
}

//保存修该后频道信息

func (this *VideoPubController) DoEdit() {
	id, _ := this.GetInt64("Id")
	if id == 0 {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	f := video.OneById(id)
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}
	title := this.GetString("Title")

	author := this.GetString("Author")

	Source := this.GetString("Source")

	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	fmt.Println("pubTime-----" + pubTimeStr)
	imgUrl := this.GetString("ImgUrl")
	fmt.Println("imgUrl------" + imgUrl)
	videoText := this.GetString("VideoText")

	publisher := this.GetString("Publisher")

	isPublish, _ := this.GetInt("IsPublish")

	readCount, _ := this.GetInt64("ReadCount")

	videoUrl := this.GetString("VideoUrl")

	f.Title = title
	f.Author = author
	f.Source = Source
	f.PubTime = pubTime
	f.TitleImg = imgUrl
	f.VideoText = videoText
	f.Publisher = publisher
	f.IsPublish = isPublish
	f.ReadCount = readCount
	f.VideoUrl = videoUrl
	err := video.Update(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/videoPub", 302)

}

func (this *VideoPubController) Del() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := video.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such video")
		return
	}

	if f.IsPublish == 1 {

		this.Ctx.WriteString("不能删除已经发布的视频!")
		return

	}

	err = video.Del(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除视频成功！")

	}

	this.Redirect("/videoPub", 302)

}
func (this *VideoPubController) Revoke() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := video.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}
	if f.IsPublish == 0 {
		this.Ctx.WriteString("该视频未发布，不能撤回！")
		return
	}
	f.IsPublish = 0
	er := video.Update(f)
	if er != nil {
		this.Ctx.WriteString(err.Error())

		return
	}
	this.Redirect("/videoPub", 302)
}

//发布视频
func (this *VideoPubController) Publish() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := video.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such video")
		return
	}

	if f.IsPublish == 1 {

		this.Ctx.WriteString("视频已经发布!")
		return
	}
	this.Data["v"] = f

	this.TplName = "publishVideo.tpl"

}

//保存发布幻灯图片,可以同时发布到频道和专题库中
func (this *VideoPubController) DoPublish() {
	id, _ := this.GetInt64("Id")
	if id == 0 {
		this.Ctx.WriteString("get Id  fail!")
		return
	}
	f := video.OneById(id)
	if f == nil {
		this.Ctx.WriteString("no such flash")
		return
	}

	nodeId, _ := this.GetInt("NodeId")
	if nodeId == 0 {
		this.Ctx.WriteString("get nodeId  fail!")
		return
	}
	siteId, _ := this.GetInt("SiteId")
	if siteId == 0 {
		this.Ctx.WriteString("get siteId fail !")
		return
	}

	//获取是否发布到专题库复选框的值

	var SpeId int64

	checkValue, _ := this.GetInt("isPubSpe")

	if checkValue == 1 {

		SpeId, _ = this.GetInt64("SpeId")

		if SpeId == 0 {

			this.Ctx.WriteString("get speId fail !")
			return
		}

	}
	//视频，发布类型为3
	var pubType = 3
	var orderId int64 = 0

	//保存到发布库
	p := &models.Publib{PubType: pubType, MetaId: id, OrderId: orderId, NodeId: nodeId, SiteId: siteId}
	_, err := publib.Save(p)

	if err == nil {

		fmt.Println("发布视频到发布库成功！")

	}
	//根据复选框的值，判断是否发布到专题库
	//保存到专题库

	if checkValue == 1 {
		s := &models.Spelib{SpecificId: SpeId, OrderId: orderId, ItemType: pubType, MetaId: id, SiteId: siteId, NodeId: nodeId}
		_, e := spelib.Save(s)

		if e == nil {

			fmt.Println("发布视频到专题库成功！")
		}

	}

	//同时更新幻灯图为已发布状态
	f.IsPublish = 1

	er := video.Update(f)

	if er == nil {

		fmt.Println("视频发布成功！")

	}
	this.Redirect("/videoPub", 302)
}
