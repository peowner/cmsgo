package controllers

import (
	"cmsgo/models"
	"cmsgo/models/push"

	"fmt"
	"strconv"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
)

type PushInfoController struct {
	beego.Controller
}

func (this *PushInfoController) Get() {
	this.TplName = "creatPush.tpl"
}

//分页处理

func (this *PushInfoController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "Id"
	}
	newses, count := push.GetPushlist(page, page_size, sort)
	if len(newses) < 1 {
		newses = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &newses}
	this.ServeJSON()
	return

}

//新建推送信息

func (this *PushInfoController) Add() {

	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["userinfo"] = userinfo

	this.TplName = "addPush.tpl"

}

//保存新建推送信息

func (this *PushInfoController) DoAdd() {
	title := this.GetString("Title")
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	content := this.GetString("Content")
	publisher := this.GetString("Publisher")
	var isPublish = 0
	n := &models.Push{Title: title, PubTime: pubTime, Content: content, IsPublish: isPublish, Publisher: publisher}
	_, err := push.Save(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/pushInfo", 302)
}

//显示当前推送信息

func (this *PushInfoController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	n := push.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such push")
		return
	}

	this.Data["Pushes"] = n

	this.TplName = "editPush.tpl"
}

//保存修该后频道信息

func (this *PushInfoController) DoEdit() {
	id, err := this.GetInt64("Id")
	if err != nil {
		this.Ctx.WriteString("get param id fail")
		return
	}

	n := push.OneById(id)
	if n == nil {
		this.Ctx.WriteString("no such push!")
		return
	}
	title := this.GetString("Title")
	isPublish, _ := this.GetInt("IsPublish")
	pubTimeStr := this.GetString("PubTime")
	fmt.Println("pubtime-----------" + pubTimeStr)
	publisher := this.GetString("Publisher")
	content := this.GetString("Content")
	pubTime, _ := time.Parse("2006-01-02 15:04:02", pubTimeStr)
	n.Title = title
	n.IsPublish = isPublish
	n.PubTime = pubTime
	n.Publisher = publisher
	n.Content = content
	err = push.Update(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/pushInfo", 302)

}

//撤回
func (this *PushInfoController) Revoke() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	n := push.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such push")
		return
	}
	if n.IsPublish == 0 {
		this.Ctx.WriteString("该推送信息没有发布，不需要撤回！")
		return
	}
	n.IsPublish = 0
	err = push.Update(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/pushInfo", 302)

}

//删除

func (this *PushInfoController) Del() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	n := push.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such push")
		return
	}

	if n.IsPublish == 1 {
		this.Ctx.WriteString("不能删除已经发布的推送信息!")
		return
	}

	err = push.Del(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除推送信息成功！")

	}

	this.Redirect("/pushInfo", 302)

}

//发布推送信息
func (this *PushInfoController) Publish() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	n := push.OneById(int64(id))
	if n == nil {
		this.Ctx.WriteString("no such push")
		return
	}

	if n.IsPublish == 1 {
		this.Ctx.WriteString("该推送信息已经发布！")
		return
	}
	n.IsPublish = 1
	err = push.Update(n)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/pushInfo", 302)

}
