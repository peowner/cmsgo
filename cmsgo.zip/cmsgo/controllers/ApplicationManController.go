package controllers

import (
	"cmsgo/models"
	"cmsgo/models/application"
	"encoding/json"
	"fmt"
	"strconv"
	"time"

	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	"github.com/ulricqin/goutils/filetool"
)

const (
	APP_ICON_DIR = "static/upload/icon"
)

type AppIconUrl struct {
	Url string
}

type ApplicationManController struct {
	beego.Controller
}

func (this *ApplicationManController) List() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["apps"] = application.All()
	this.TplName = "creatApp.tpl"
}

func (this *ApplicationManController) Add() {
	userinfo := this.GetSession("userinfo")
	if userinfo == nil {
		this.Ctx.Redirect(302, beego.AppConfig.String("rbac_auth_gateway"))
	}
	this.Data["userinfo"] = userinfo
	this.TplName = "addApp.tpl"
}

//分页处理

func (this *ApplicationManController) Index() {
	page, _ := this.GetInt64("page")
	page_size, _ := this.GetInt64("rows")
	sort := this.GetString("sort")
	order := this.GetString("order")
	if len(order) > 0 {
		if order == "desc" {
			sort = "-" + sort
		}
	} else {
		sort = "-Id"
	}
	apps, count := application.GetApplicationList(page, page_size, sort)
	if len(apps) < 1 {
		apps = []orm.Params{}
	}
	this.Data["json"] = &map[string]interface{}{"total": count, "rows": &apps}
	this.ServeJSON()
	return

}

//保存上传应用图标
func (this *ApplicationManController) DoUpload() {
	var imgPath string
	imgPaths := []AppIconUrl{}
	img := AppIconUrl{}

	_, header, err := this.GetFile("ImgPath")
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}
	ext := filetool.Ext(header.Filename)
	imgPath = fmt.Sprintf("%s/%d%s", APP_ICON_DIR, time.Now().Unix(), ext)
	img.Url = imgPath
	imgPaths = append(imgPaths, img)
	result, err := json.Marshal(img)
	this.Ctx.WriteString(string(result))
	fmt.Println("输出的图片路径json-----" + string(result))
	fmt.Println("开始保存幻灯图片")
	filetool.InsureDir(APP_ICON_DIR)

	err = this.SaveToFile("ImgPath", imgPath)

	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

}

//保存新建幻灯图片
func (this *ApplicationManController) DoAdd() {
	Type, _ := this.GetInt("Type")
	Name := this.GetString("Name")
	Url := this.GetString("Url")
	Icon := this.GetString("Icon")
	Waptype, _ := this.GetInt("Waptype")
	Sort, _ := this.GetInt("Sort")
	f := &models.Application{Type: Type, Name: Name, Url: Url, Icon: Icon, Waptype: Waptype, Sort: Sort}
	_, err := application.Save(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())

		return
	}
	this.Redirect("/appPub", 302)
}

//修改应用
//显示当前修改信息

func (this *ApplicationManController) Edit() {
	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}
	f := application.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such app")
		return
	}

	this.Data["App"] = f

	this.TplName = "editApp.tpl"
}

//保存修该后信息

func (this *ApplicationManController) DoEdit() {
	id, _ := this.GetInt64("Id")
	if id == 0 {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	f := application.OneById(id)
	if f == nil {
		this.Ctx.WriteString("no such app")
		return
	}
	ty, _ := this.GetInt("Type")
	name := this.GetString("Name")
	url := this.GetString("Url")
	icon := this.GetString("Icon")
	waptype, _ := this.GetInt("Waptype")
	sort, _ := this.GetInt("Sort")
	f.Type = ty
	f.Name = name
	f.Url = url
	f.Icon = icon
	f.Waptype = waptype
	f.Sort = sort
	err := application.Update(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	}

	this.Redirect("/appPub", 302)

}

func (this *ApplicationManController) DoDel() {

	Id := this.GetString("Id")
	if Id == "" {
		this.Ctx.WriteString("get param Id fail")
		return
	}

	id, err := strconv.Atoi(Id)
	if err != nil {

		fmt.Println("Id conv err!")

	}

	f := application.OneById(int64(id))
	if f == nil {
		this.Ctx.WriteString("no such App")
		return
	}

	err = application.Del(f)
	if err != nil {
		this.Ctx.WriteString(err.Error())
		return
	} else {

		fmt.Println("删除幻灯图片成功！")

	}

	this.Redirect("/appPub", 302)

}
