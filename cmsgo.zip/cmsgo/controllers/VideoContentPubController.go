package controllers

import (
	"fmt"

	"github.com/astaxie/beego"
)

type VideoContentPubController struct {
	beego.Controller
}

func (this *VideoContentPubController) Get() {
	this.Data["Website"] = "beego.me"
	this.Data["Email"] = "astaxie@gmail.com"
	this.TplName = "creatImage.tpl"
	id := this.Ctx.Input.Param(":id")
	fmt.Println("获得的视频id----------" + id)
}
