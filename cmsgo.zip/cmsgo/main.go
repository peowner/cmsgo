package main

import (
	"cmsgo/controllers"
	"github.com/astaxie/beego"
	"strconv"
)

func StringsToJson(str string) string {
	rs := []rune(str)
	jsons := ""
	for _, r := range rs {
		rint := int(r)
		if rint < 128 {
			jsons += string(r)
		} else {
			jsons += "\\u" + strconv.FormatInt(int64(rint), 16) // json
		}
	}

	return jsons
}

func main() {
	//beego.EnableAdmin = true
	beego.SetLogger("file", `{"filename":"logs/cms.log"}`)

	beego.AddFuncMap("stringsToJson", StringsToJson)

	//系统登录

	beego.Router("/", &controllers.MainController{}, "*:Login")

	//业务系统入口
	beego.Router("/index", &controllers.MainController{}, "get:Work")

	//后台管理路由

	beego.Router("/public/index", &controllers.MainController{}, "*:Index")
	beego.Router("/public/login", &controllers.MainController{}, "*:Login")
	beego.Router("/public/logout", &controllers.MainController{}, "*:Logout")
	beego.Router("/public/changepwd", &controllers.MainController{}, "*:Changepwd")
	//修改密码
	beego.Router("/public/renewPwd", &controllers.MainController{}, "get:Editpwd")

	//用户管理
	beego.Router("/rbac/user/AddUser", &controllers.UserController{}, "*:AddUser")
	beego.Router("/rbac/user/UpdateUser", &controllers.UserController{}, "*:UpdateUser")
	beego.Router("/rbac/user/DelUser", &controllers.UserController{}, "*:DelUser")
	beego.Router("/rbac/user/index", &controllers.UserController{}, "*:Index")

	beego.Router("/rbac/permission/AddAndEdit", &controllers.PermissionController{}, "*:AddAndEdit")
	beego.Router("/rbac/permission/DelPermission", &controllers.PermissionController{}, "*:DelPermission")
	beego.Router("/rbac/permission/index", &controllers.PermissionController{}, "*:Index")
	//组管理
	beego.Router("/rbac/group/AddGroup", &controllers.GroupController{}, "*:AddGroup")
	beego.Router("/rbac/group/UpdateGroup", &controllers.GroupController{}, "*:UpdateGroup")
	beego.Router("/rbac/group/DelGroup", &controllers.GroupController{}, "*:DelGroup")
	beego.Router("/rbac/group/index", &controllers.GroupController{}, "*:Index")
	//角色管理
	beego.Router("/rbac/role/AddAndEdit", &controllers.RoleController{}, "*:AddAndEdit")
	beego.Router("/rbac/role/DelRole", &controllers.RoleController{}, "*:DelRole")
	beego.Router("/rbac/role/AccessToPermission", &controllers.RoleController{}, "*:AccessToPermission")
	beego.Router("/rbac/role/AddAccess", &controllers.RoleController{}, "*:AddAccess")
	beego.Router("/rbac/role/RoleToUserList", &controllers.RoleController{}, "*:RoleToUserList")
	beego.Router("/rbac/role/AddRoleToUser", &controllers.RoleController{}, "*:AddRoleToUser")
	beego.Router("/rbac/role/Getlist", &controllers.RoleController{}, "*:Getlist")
	beego.Router("/rbac/role/index", &controllers.RoleController{}, "*:Index")

	//站点管理的路由和控制器定义

	beego.Router("/addSite", &controllers.SiteManageController{}, "get:AddSite")

	beego.Router("/siteManage", &controllers.SiteManageController{}, "get:Add;post:DoAdd")

	beego.Router("/editSite", &controllers.SiteManageController{}, "post:Edit")

	beego.Router("/saveSite", &controllers.SiteManageController{}, "post:DoEdit")

	beego.Router("/delSite", &controllers.SiteManageController{}, "post:Del")

	//分页处理
	beego.Router("/listSite", &controllers.SiteManageController{}, "post:Index")

	//发布库路由和控制器定义
	beego.Router("/pubLib", &controllers.PubLibController{})
	//发布库分页
	beego.Router("/listPub", &controllers.PubLibController{}, "post:Index")
	//发布库撤回
	beego.Router("/revokePublib", &controllers.PubLibController{}, "post:Revoke")
	//幻灯发布路由和控制器

	beego.Router("/flashPub", &controllers.FlashPubController{}, "get:List")

	//新增幻灯操作路由和控制器

	beego.Router("/addFlash", &controllers.FlashPubController{}, "get:Add;post:DoAdd")

	//修改幻灯图片
	beego.Router("/editFlash", &controllers.FlashPubController{}, "post:Edit")
	//保存修改
	beego.Router("/saveFlash", &controllers.FlashPubController{}, "post:DoEdit")

	//删除幻灯图片
	beego.Router("/delFlash", &controllers.FlashPubController{}, "post:DoDel")

	//上传幻灯图片路由和控制器

	beego.Router("/uploadFlash", &controllers.FlashPubController{}, "post:DoUpload")

	//发布幻灯图片
	beego.Router("/savePublishFlash", &controllers.FlashPubController{}, "post:DoPublish")

	//保存幻灯发布

	beego.Router("/publishFlash", &controllers.FlashPubController{}, "post:Publish")

	//处理分页

	beego.Router("/listFlash", &controllers.FlashPubController{}, "post:Index")

	//flash发布库管理
	beego.Router("/listFlashPublish", &controllers.FlashPublishLibController{})
	beego.Router("/listFlashPubLib", &controllers.FlashPublishLibController{}, "post:Index")
	//flash发布库撤回
	beego.Router("/revokePublibFlash", &controllers.FlashPublishLibController{}, "post:Revoke")

	//视频发布路由和控制器定义

	beego.Router("/videoPub", &controllers.VideoPubController{})

	//保存视频标题图片
	beego.Router("/uploadVideoImg", &controllers.VideoPubController{}, "post:UploadImg")

	//保存视频文件
	beego.Router("/uploadVideo", &controllers.VideoPubController{}, "post:UploadVideo")

	//分页
	beego.Router("/listVideo", &controllers.VideoPubController{}, "post:Index")

	//新建视频
	beego.Router("/addVideo", &controllers.VideoPubController{}, "get:Add")
	//保存新建视频
	beego.Router("/saveVideo", &controllers.VideoPubController{}, "post:DoAdd")
	//修改视频
	beego.Router("/editVideo", &controllers.VideoPubController{}, "post:Edit")

	//保存修改视频
	beego.Router("/saveEditVideo", &controllers.VideoPubController{}, "post:DoEdit")

	//删除视频
	beego.Router("/delVideo", &controllers.VideoPubController{}, "post:Del")
	//发布视频

	beego.Router("/publishVideo", &controllers.VideoPubController{}, "post:Publish")

	//保存发布视频

	beego.Router("/savePublishVideo", &controllers.VideoPubController{}, "post:DoPublish")

	//撤回视频
	beego.Router("/RevokeVideo", &controllers.VideoPubController{}, "post:Revoke")

	//图片发布路由和控制器定义
	beego.Router("/imagePub", &controllers.ImagePubController{})
	//上传图片
	beego.Router("/uploadImage", &controllers.ImagePubController{}, "post:DoUpload")

	//通用编辑器中上传内容图片

	beego.Router("/upload_content_Image", &controllers.ImagePubController{}, "post:UploadContentImg")

	//分页图片
	beego.Router("/imageList", &controllers.ImagePubController{}, "post:Index")
	//新建图片
	beego.Router("/addImage", &controllers.ImagePubController{}, "get:Add")
	//保存新建
	beego.Router("/saveImage", &controllers.ImagePubController{}, "post:DoAdd")
	//修改图片
	beego.Router("/editImage", &controllers.ImagePubController{}, "post:Edit")
	//保存修改
	beego.Router("/saveEditImage", &controllers.ImagePubController{}, "post:DoEdit")
	//删除图片
	beego.Router("/delImage", &controllers.ImagePubController{}, "post:DoDel")
	//撤回图片
	//beego.Router("/revokeImage/:id([0-9]+)", &controllers.ImagePubController{}, "post:Revoke")
	//发布图片
	beego.Router("/publishImage", &controllers.ImagePubController{}, "post:Publish")
	//保存发布
	beego.Router("/savePublishImage", &controllers.ImagePubController{}, "post:DoPublish")
	//推广中心
	//广告封面图发布
	beego.Router("/adimagePub", &controllers.AdImagePubController{})
	//分页广告封面图片
	beego.Router("/adimageList", &controllers.AdImagePubController{}, "post:Index")
	//新建图片
	beego.Router("/addAdImage", &controllers.AdImagePubController{}, "get:Add")
	//保存新建
	beego.Router("/saveAdImage", &controllers.AdImagePubController{}, "post:DoAdd")
	//修改图片
	beego.Router("/editadImage", &controllers.AdImagePubController{}, "*:ShowEdit")
	//保存修改
	beego.Router("/saveEditAdImage", &controllers.AdImagePubController{}, "post:DoEdit")
	//删除图片
	beego.Router("/deladImage", &controllers.AdImagePubController{}, "*:DoDel")
	//发布图片
	beego.Router("/publishAdImage", &controllers.AdImagePubController{}, "post:Publish")
	//撤回封面广告图
	beego.Router("/revokeAdImage", &controllers.AdImagePubController{}, "post:Revoke")
	//内容广告推广
	beego.Router("/adContentimagePub", &controllers.AdContentImagePubController{})
	//分页内容广告图片
	beego.Router("/adContentimageList", &controllers.AdContentImagePubController{}, "post:Index")
	//新建图片
	beego.Router("/addAdContentImage", &controllers.AdContentImagePubController{}, "get:Add")
	//保存新建
	beego.Router("/saveAdContentImage", &controllers.AdContentImagePubController{}, "post:DoAdd")
	//修改图片
	beego.Router("/editadContentImage", &controllers.AdContentImagePubController{}, "*:ShowEdit")
	//保存修改
	beego.Router("/saveEditAdContentImage", &controllers.AdContentImagePubController{}, "post:DoEdit")
	//删除图片
	beego.Router("/deladContentImage", &controllers.AdContentImagePubController{}, "*:DoDel")
	//发布图片
	beego.Router("/publishAdContentImage", &controllers.AdContentImagePubController{}, "post:Publish")
	//撤回内容广告图
	beego.Router("/revokeAdContentImage", &controllers.AdContentImagePubController{}, "post:Revoke")
	//幻灯图片广告推广
	beego.Router("/adflashimagePub", &controllers.AdFlashImagePubController{})
	//分页幻灯广告图片
	beego.Router("/adFlashimageList", &controllers.AdFlashImagePubController{}, "post:Index")
	//新建幻灯广告图片
	beego.Router("/addAdFlashImage", &controllers.AdFlashImagePubController{}, "post:Add")
	//保存新建幻灯广告图片

	beego.Router("/saveAdFlashImage", &controllers.AdFlashImagePubController{}, "post:DoAdd")

	//修改幻灯广告图片

	//修改图片
	beego.Router("/editadFlashImage", &controllers.AdFlashImagePubController{}, "*:ShowEdit")
	//保存修改
	beego.Router("/saveEditAdFlashImage", &controllers.AdFlashImagePubController{}, "post:DoEdit")
	//删除图片
	beego.Router("/deladFlashImage", &controllers.AdFlashImagePubController{}, "*:DoDel")
	//发布图片
	beego.Router("/publishAdFlashImage", &controllers.AdFlashImagePubController{}, "post:Publish")
	//撤回内容广告图
	beego.Router("/revokeAdFlashImage", &controllers.AdFlashImagePubController{}, "post:Revoke")

	//组图
	beego.Router("/imgGroupPub", &controllers.ImgGroupPubController{})

	//组图分页
	beego.Router("/imgGroupList", &controllers.ImgGroupPubController{}, "post:Index")

	//新建组图分类
	beego.Router("/addImgGroup", &controllers.ImgGroupPubController{}, "get:Add")
	//保存新建组图

	beego.Router("/saveImgGroup", &controllers.ImgGroupPubController{}, "post:DoAdd")

	//修改组图
	beego.Router("/editImgGroup", &controllers.ImgGroupPubController{}, "post:Edit")
	//保存修改结果
	beego.Router("/saveEditImgGroup", &controllers.ImgGroupPubController{}, "post:DoEdit")
	//发布组图
	beego.Router("/publishImgGroup", &controllers.ImgGroupPubController{}, "post:Publish")
	//保存发布结果
	beego.Router("/doPublishImgGroup", &controllers.ImgGroupPubController{}, "post:DoPublish")
	//删除组图
	beego.Router("/delImgGroup", &controllers.ImgGroupPubController{}, "post:Del")

	//组图中添加单张图片
	beego.Router("/AddImgToGroup", &controllers.ImgGroupPubController{}, "post:AddImgToGroup")
	//保存添加单张图片到组图
	beego.Router("/DoAddImgToGroup", &controllers.ImgGroupPubController{}, "post:DoAddImgToGroup")
	//专题发布路由和控制器定义specific
	beego.Router("/specificPub", &controllers.SpecificPubController{})

	//新建专题
	beego.Router("/addSpecific", &controllers.SpecificPubController{}, "get:Add")
	//保存修改专题
	beego.Router("/saveSpecific", &controllers.SpecificPubController{}, "post:DoAdd")
	//修改专题
	beego.Router("/editSpecific", &controllers.SpecificPubController{}, "post:Edit")
	//保存修改专题

	beego.Router("/doEditSpecific", &controllers.SpecificPubController{}, "post:DoEdit")

	//分页
	beego.Router("/listSpecific", &controllers.SpecificPubController{}, "post:Index")
	//专题库中撤回发布
	beego.Router("/revokeSpeLib", &controllers.SpecificLibController{}, "post:RevokeSpeLib")
	//专题库中发布管理
	beego.Router("/specificLib", &controllers.SpecificLibController{})

	//分页专题发布库
	beego.Router("/listSpecificLib", &controllers.SpecificLibController{}, "post:Index")

	//保存专题图片

	beego.Router("/upLoadSpecific", &controllers.SpecificPubController{}, "post:DoUpload")

	//删除专题
	beego.Router("/delSpecific", &controllers.SpecificPubController{}, "post:DoDel")

	//发布专题
	beego.Router("/publishSpecific", &controllers.SpecificPubController{}, "post:Publish")
	//保存发布
	beego.Router("/doPublishSpecific", &controllers.SpecificPubController{}, "post:DoPublish")

	//撤回专题
	beego.Router("/revokeSpecific", &controllers.SpecificPubController{}, "post:DoRev")

	//专题json输出

	beego.Router("/specificList", &controllers.SpecificPubController{}, "get:List")

	//新闻发布路由和控制器

	beego.Router("/newsPub", &controllers.AddNewsController{})

	//新建普通新闻路由和控制器

	beego.Router("/addNews", &controllers.AddNewsController{}, "get:Add")
	//新建保存新闻

	beego.Router("/saveNews", &controllers.AddNewsController{}, "post:DoAdd")

	//修改新闻
	beego.Router("/editNews", &controllers.AddNewsController{}, "post:Edit")

	//保存修改新闻
	beego.Router("/saveEditNews", &controllers.AddNewsController{}, "post:DoEdit")

	//发布新闻
	beego.Router("/publishNews", &controllers.AddNewsController{}, "post:Publish")

	//保存发布新闻
	beego.Router("/savePublishNews", &controllers.AddNewsController{}, "post:DoPublish")

	//撤回发布新闻

	beego.Router("/revokeNews", &controllers.AddNewsController{}, "post:Revoke")

	//删除新闻
	beego.Router("/delNews", &controllers.AddNewsController{}, "post:Del")

	//新闻分页

	beego.Router("/listNews", &controllers.AddNewsController{}, "post:Index")

	//上传新闻标题图片

	beego.Router("/uploadNewsImg", &controllers.AddNewsController{}, "post:DoUpload")

	//推送管理

	beego.Router("/pushInfo", &controllers.PushInfoController{}, "get:Get")

	//分页列表
	beego.Router("/pushInfoList", &controllers.PushInfoController{}, "post:Index")
	//新建推送信息
	beego.Router("/addPushInfo", &controllers.PushInfoController{}, "get:Add")

	//保存新建推送信息
	beego.Router("/saveAddPushInfo", &controllers.PushInfoController{}, "post:DoAdd")
	//修改推送信息
	beego.Router("/editPushInfo", &controllers.PushInfoController{}, "post:Edit")
	//保存修改信息
	beego.Router("/saveEditPushInfo", &controllers.PushInfoController{}, "post:DoEdit")
	//删除推送信息
	beego.Router("/delPushInfo", &controllers.PushInfoController{}, "post:Del")
	//发布推送信息
	beego.Router("/publishPushInfo", &controllers.PushInfoController{}, "post:Publish")
	//撤回推送信息
	beego.Router("/revokePushInfo", &controllers.PushInfoController{}, "post:Revoke")

	//频道管理的路由和控制器

	beego.Router("/nodeManage", &controllers.NodeManageController{}, "get:List;post:DoAdd")

	//新建频道的路由和控制器
	beego.Router("/addNode", &controllers.AddNodeController{})

	//复用控制器，实现频道的修改和删除功能

	beego.Router("/editNode", &controllers.NodeManageController{}, "post:Edit")
	//保存修改后频道信息路由和控制器定义

	beego.Router("/saveNode", &controllers.NodeManageController{}, "post:DoEdit")

	//删除频道

	beego.Router("/delNode", &controllers.NodeManageController{}, "get:List;post:DoDel")

	//处理分页

	beego.Router("/listNode", &controllers.NodeManageController{}, "post:Index")

	//输出频道json信息接口

	beego.Router("/nodeList", &controllers.NodeListController{}, "get:Get")

	beego.Router("/nodeListJson", &controllers.NodeListController{}, "post:Post")

	//统计模块
	//beego.Router("/articleCount", &controllers.CountController{}, "post:CountArticle")
	//beego.Router("/accessCount", &controllers.CountController{}, "post:CountAccess")

	//应用管理
	beego.Router("/appPub", &controllers.ApplicationManController{}, "get:List")
	beego.Router("/appList", &controllers.ApplicationManController{}, "post:Index")
	beego.Router("/appAdd", &controllers.ApplicationManController{}, "get:Add")
	beego.Router("/saveAppAdd", &controllers.ApplicationManController{}, "post:DoAdd")
	beego.Router("/appEdit", &controllers.ApplicationManController{}, "post:Edit")
	beego.Router("/saveAppEdit", &controllers.ApplicationManController{}, "post:DoEdit")
	beego.Router("/appDel", &controllers.ApplicationManController{}, "post:DoDel")
	beego.Router("/appUploadIcon", &controllers.ApplicationManController{}, "post:DoUpload")
	//订报管理
	beego.Router("/orderMan", &controllers.ActionController{}, "get:ListOrder")
	//显示给客户端的订报页面
	beego.Router("/order", &controllers.ActionController{}, "get:ListOrderApp")

	//订报分页
	beego.Router("/orderList", &controllers.ActionController{}, "post:IndexOrder")
	//保存订报信息
	beego.Router("/save", &controllers.ActionController{}, "post:SaveOrder")
	//删除订报信息
	beego.Router("/orderDel", &controllers.ActionController{}, "post:DelOrder")
	//处理订报信息
	beego.Router("/orderProcess", &controllers.ActionController{}, "post:DoOrder")
	//报料管理
	beego.Router("/reportMan", &controllers.ActionController{}, "get:ListReport")
	//报料分页
	beego.Router("/reportList", &controllers.ActionController{}, "post:IndexReport")
	//保存客户端提交爆料信息
	beego.Router("/reportSave", &controllers.ActionController{}, "get:SaveReport")
	//删除报料
	beego.Router("/reportDel", &controllers.ActionController{}, "post:DoDel")
	//处理报料
	beego.Router("/reportPro", &controllers.ActionController{}, "post:DoPro")
	//直播管理

	beego.Router("/liveMan", &controllers.LiveController{}, "get:GetLive")
	//直播分页
	beego.Router("/liveList", &controllers.LiveController{}, "post:LiveList")
	//新建直播
	beego.Router("/liveAdd", &controllers.LiveController{}, "get:AddLive")
	//保存新建直播
	beego.Router("/DoAddLive", &controllers.LiveController{}, "post:DoAddLive")

	//直播内容发布
	beego.Router("/liveContentMan", &controllers.LiveController{}, "get:GetLiveContent")
	//直播内容分页
	beego.Router("/liveContentIndex", &controllers.LiveController{}, "post:GetLiveContentList")
	//活动中心
	beego.Router("/actionMan", &controllers.ActionController{}, "get:ActionIndex")

	//分页活动
	beego.Router("/actionList", &controllers.ActionController{}, "post:ActionList")

	//创建活动
	beego.Router("/actionAdd", &controllers.ActionController{}, "get:ActionAdd")
	//保存创建活动
	beego.Router("/actionDoAdd", &controllers.ActionController{}, "post:ActionDoAdd")
	//修改活动
	beego.Router("/actionEdit", &controllers.ActionController{}, "post:ActionEdit")
	//保存修改活动
	beego.Router("/actionDoEdit", &controllers.ActionController{}, "post:ActionDoEdit")
	//删除活动
	beego.Router("/actionDel", &controllers.ActionController{}, "post:ActionDel")

	//用户中心

	//输出站点json信息接口

	beego.Router("/siteList", &controllers.SiteListController{})

	//普通新闻内容页接口，根据稿件id显示内容

	beego.Router("/newsContentPub", &controllers.NewsContentPubController{})

	//图片新闻内容发布接口，根据组图中的图片id输出所有该组图中图片的json信息

	beego.Router("/imagesPub", &controllers.ImagesPubController{})

	//视频新闻内容发布接口，根据视频id显示内容

	beego.Router("/videoContentPub", &controllers.VideoContentPubController{})

	//专题发布接口，根据专题id显示列表
	beego.Router("/specificListPub", &controllers.SpecificListPubController{})

	//幻灯图发布接口，根据Id显示幻灯图详细内容

	beego.Router("/flashContengPub", &controllers.FlashContentPubController{})
	//app客户端发布接口
	//发布库json数据
	beego.Router("/getNewsList", &controllers.ApiInterfaceController{}, "get:GetNewsList")
	//提供给客户端新闻元数据列表
	beego.Router("/getNewsMeta", &controllers.ApiInterfaceController{}, "get:GetNewsMeta")

	beego.Router("/apiGetJsonById", &controllers.ApiInterfaceController{}, "get:GetJsonById")

	//客户端专题列表GetSpeList
	beego.Router("/apiGetSpeList", &controllers.ApiInterfaceController{}, "get:GetSpeList")

	//幻灯库json数据
	beego.Router("/apiFlash", &controllers.ApiInterfaceController{}, "get:GetFlash")

	//营销中心
	//刮刮卡
	beego.Router("/cardApi", &controllers.ApiInterfaceController{}, "get:Card")
	//大转盘
	beego.Router("/lotteryApi", &controllers.ApiInterfaceController{}, "get:Lottery")
	//砸金蛋
	beego.Router("/eggApi", &controllers.ApiInterfaceController{}, "get:Egg")

	//客户端获得应用发布接口

	beego.Router("/getApplication", &controllers.ApiInterfaceController{}, "get:GetApp")

	//客户端启动时广告界面图片地址发布接口

	beego.Router("/getWelcomImgUrl", &controllers.ApiInterfaceController{}, "get:GetWelcomImgUrl")

	//客户端资讯列表
	beego.Router("/apiGetInfoList", &controllers.ApiInterfaceController{}, "get:GetInfoList")
	//客户端资讯内容发布接口
	beego.Router("/getInfoContentById", &controllers.ApiInterfaceController{}, "get:InfoContentApi")

	//客户端活动列表发布接口

	beego.Router("/getActionList", &controllers.ApiInterfaceController{}, "get:ActionApi")

	//客户端活动内容发布接口
	beego.Router("/getActionContentById", &controllers.ApiInterfaceController{}, "get:ActionContentApi")
	//客户端新闻内容发布接口
	beego.Router("/getNewsContentById", &controllers.ApiInterfaceController{}, "get:NewsContentApi")

	//用户中心
	//保存客户端提交的意见反馈
	beego.Router("/suggestionMan", &controllers.SuggestionController{}, "get:Get")
	//建议分页
	beego.Router("/suggestionList", &controllers.SuggestionController{}, "post:Index")
	//客户端保存建议
	beego.Router("/suggestionSave", &controllers.SuggestionController{}, "get:SaveSuggestion")
	//删除建议
	beego.Router("/suggestionDel", &controllers.SuggestionController{}, "post:DoDel")
	//处理建议
	beego.Router("/suggestionProcess", &controllers.SuggestionController{}, "post:Done")
	//关于我们
	beego.Router("/aboutMan", &controllers.AboutController{}, "get:Get")
	//关于我们分页
	beego.Router("/aboutList", &controllers.AboutController{}, "post:AboutList")
	//新建关于我们
	beego.Router("/aboutAdd", &controllers.AboutController{}, "get:AboutAdd")
	//保存新建关于我们
	beego.Router("/aboutDoAdd", &controllers.AboutController{}, "post:AboutDoAdd")

	//修改关于我们信息
	beego.Router("/aboutEdit", &controllers.AboutController{}, "post:AboutEdit")
	//保存修改关于我们信息
	beego.Router("/AboutDoEdit", &controllers.AboutController{}, "post:AboutDoEdit")
	//删除关于我们信息
	beego.Router("/AboutDel", &controllers.AboutController{}, "post:AboutDel")

	//提供给客户端端关于我们信息
	beego.Router("/AboutUs", &controllers.AboutController{}, "get:AboutUs")

	//提供给客户端组图中单图信息
	beego.Router("/getImgFromGroupById", &controllers.ApiInterfaceController{}, "get:GetImgFromGroupById")

	beego.Run()
}
