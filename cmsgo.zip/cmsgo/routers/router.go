package routers

import (
	"cmsgo/controllers"
	"github.com/astaxie/beego"
)
