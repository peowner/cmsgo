package flash

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetFlashlist(page int64, page_size int64, sort string) (flashes []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(Flash)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&flashes, "Id", "Title", "ImgUrl", "ImgText", "PubTime", "Source", "Author", "IsPublish", "Publisher", "ReadCount")
	count, _ = qs.Count()
	return flashes, count
}

//根据Id获取单个幻灯图片
func OneById(id int64) *Flash {
	if id <= 0 {
		return nil
	}
	o := Flash{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部幻灯图片
func AllIdsInDB() []int64 {
	var flashes []Flash
	Flashes().OrderBy("-Id").All(&flashes, "Id")
	size := len(flashes)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = flashes[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*Flash {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Flash{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*Flash, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建幻灯图片业务流程
func Save(this *Flash) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存幻灯图片成功！------")
	}

	return id, err
}

//删除幻灯图片业务流程

func Del(f *Flash) error {
	_, err := Flashes().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改幻灯图片业务流程

func Update(f *Flash) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改幻灯图片成功！")
	}
	return err
}

//发布幻灯图片业务流程

func Publish(f *Flash) error {

	f.IsPublish = 1
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("发布幻灯图片成功！")
	}
	return err
}

//撤回幻灯图片业务流程

func Revoke(f *Flash) error {

	f.IsPublish = 0
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("撤回幻灯图片成功！")
	}
	return err

}

func Flashes() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Flash))
}
