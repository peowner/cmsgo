package host

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetHostList(page int64, page_size int64, sort string) (hosts []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(Host)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&hosts, "Id", "HostImg", "HostName", "LoginId", "HostId", "HostPw")
	count, _ = qs.Count()
	return hosts, count
}

//根据Id获取单个主持人
func OneById(id int64) *Host {
	if id <= 0 {
		return nil
	}
	o := Host{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部直播
func AllIdsInDB() []int64 {
	var hosts []Host
	Hosts().OrderBy("-Id").All(&hosts, "Id")
	size := len(hosts)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = hosts[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*Host {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Host{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*Host, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建直播主持人流程
func Save(this *Host) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存直播主持人成功！------")
	}

	return id, err
}

//删除主持人流程

func Del(f *Host) error {
	_, err := Hosts().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改直播主持人流程

func Update(f *Host) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改直播主持人信息成功！")
	}
	return err
}

func Hosts() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Host))
}
