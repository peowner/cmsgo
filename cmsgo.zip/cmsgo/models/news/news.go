package news

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页处理
func GetNewslist(page int64, page_size int64, sort string) (newses []orm.Params, count int64) {
	o := orm.NewOrm()
	n := new(News)
	qs := o.QueryTable(n)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&newses, "Id", "Title", "Content", "Subject", "TitleImg", "PubTime", "Source", "Author", "IsPublish", "Publisher", "ReadCount")
	count, _ = qs.Count()
	return newses, count
}

//根据Id获取单个新闻
func OneById(id int64) *News {
	if id <= 0 {
		return nil
	}
	o := News{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

func AllIdsInDB() []int64 {
	var newses []News
	Newses().OrderBy("Id").All(&newses, "Id")
	size := len(newses)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = newses[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

func All() []*News {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*News{}
	}

	ret := make([]*News, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

func Save(this *News) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("新建新闻成功！------")
	}

	return id, err
}

func Del(n *News) error {
	_, err := Newses().Filter("Id", n.Id).Delete()
	if err != nil {
		return err
	}
	return nil
}

func Update(n *News) error {
	if n.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(n)
	if err == nil {
		fmt.Println("修改新闻成功！")
	}
	return err
}

func Newses() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(News))
}
