package adcontentimg

import (
	. "cmsgo/models"
	"fmt"
	"github.com/astaxie/beego/orm"
)

//分页列表

func GetAdContentImagelist(page int64, page_size int64, sort string) (AdContentimages []orm.Params, count int64) {
	o := orm.NewOrm()
	i := new(AdContentImg)
	qs := o.QueryTable(i)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&AdContentimages, "Id", "Title", "ImgUrl", "ImgText", "PubTime", "Source", "Author", "IsPublish", "Publisher", "ReadCount", "Content", "Number")
	count, _ = qs.Count()
	return AdContentimages, count
}

//根据Id获取单个图片
func OneById(id int64) *AdContentImg {
	if id <= 0 {
		return nil
	}
	o := AdContentImg{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部图片
func AllIdsInDB() []int64 {
	var adimages []AdContentImg
	AdContentImgs().OrderBy("-Id").All(&adimages, "Id")
	size := len(adimages)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = adimages[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*AdContentImg {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*AdContentImg{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*AdContentImg, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建图片业务流程
func Save(this *AdContentImg) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存图片成功！------")
	}

	return id, err
}

//删除图片业务流程

func Del(f *AdContentImg) error {
	_, err := AdContentImgs().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改图片业务流程

func Update(f *AdContentImg) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改图片成功！")
	}
	return err
}

//发布图片业务流程

func Publish(f *AdContentImg) error {

	f.IsPublish = 1
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("发布图片成功！")
	}
	return err
}

//撤回图片业务流程

func Revoke(f *AdContentImg) error {

	f.IsPublish = 0
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("撤回图片成功！")
	}
	return err

}

func AdContentImgs() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(AdContentImg))
}
