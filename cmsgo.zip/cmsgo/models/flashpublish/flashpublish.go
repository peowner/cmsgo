package flashpublish

import (
	. "cmsgo/models"
	"fmt"
	"github.com/astaxie/beego/orm"
)

//分页处理
func GetFlashMetalist(page int64, page_size int64, sort string) (flashMetas []orm.Params, count int64) {
	o := orm.NewOrm()
	n := new(FlashPublib)
	qs := o.QueryTable(n)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&flashMetas, "Id", "PubType", "MetaId", "OrderId", "NodeId", "SiteId")
	count, _ = qs.Count()
	return flashMetas, count
}
func OneById(id int64) *FlashPublib {
	if id <= 0 {
		return nil
	}
	o := FlashPublib{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//api接口查询

//参数为请求的页码

func ApiFlashMetalist(page int64, page_size int64, sort string, nodeId int64) (flashMetas []orm.Params, count int64) {
	o := orm.NewOrm()
	p := new(FlashPublib)
	qs := o.QueryTable(p)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).Filter("NodeId", nodeId).OrderBy(sort).Values(&flashMetas, "Id", "PubType", "MetaId", "OrderId", "NodeId", "SiteId")
	count, _ = qs.Count()
	return flashMetas, count
}

//发布保存
func Save(this *FlashPublib) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存flash元数据到发布库成功！------")
	}

	return id, err
}
func Del(n *FlashPublib) error {
	_, err := FlashPublishs().Filter("Id", n.Id).Delete()
	if err != nil {
		return err
	}
	return nil
}
func Update(n *FlashPublib) error {
	if n.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(n)
	if err == nil {
		fmt.Println("修改发布flash元数据成功！")
	}
	return err
}

func FlashPublishs() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(FlashPublib))
}
