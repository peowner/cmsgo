package livecontent

import (
	. "cmsgo/models"

	"fmt"
	"github.com/astaxie/beego/orm"
)

//分页列表

func GetLiveContentList(page int64, page_size int64, sort string) (liveContents []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(LiveContent)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&liveContents, "Id", "LiveId", "LiveText", "ImgUrl", "VideoUrl", "AudioUrl", "PubTime")
	count, _ = qs.Count()
	return liveContents, count
}

//根据Id获取单个直播内容
func OneById(id int64) *LiveContent {
	if id <= 0 {
		return nil
	}
	o := LiveContent{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部直播内容
func AllIdsInDB() []int64 {
	var livecontents []LiveContent
	LiveContents().OrderBy("-Id").All(&livecontents, "Id")
	size := len(livecontents)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = livecontents[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*LiveContent {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*LiveContent{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*LiveContent, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建直播内容流程
func Save(this *LiveContent) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存直播内容成功！------")
	}

	return id, err
}

//删除直播内容流程

func Del(f *LiveContent) error {
	_, err := LiveContents().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改直播内容流程

func Update(f *LiveContent) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改直播内容成功！")
	}
	return err
}

func LiveContents() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(LiveContent))
}
