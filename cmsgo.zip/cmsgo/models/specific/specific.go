package specific

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetSpecificlist(page int64, page_size int64, sort string) (specifics []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(Specific)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&specifics, "Id", "SpecialTitle", "SpecialText", "IsPublish", "PubTime", "ReadCount", "SiteId", "ImgUrl", "PubType")
	count, _ = qs.Count()
	return specifics, count
}

func OneById(id int64) *Specific {
	if id <= 0 {
		return nil
	}
	o := Specific{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

func AllIdsInDB() []int64 {
	var specifics []Specific
	Specifics().OrderBy("-Id").All(&specifics, "Id")
	size := len(specifics)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = specifics[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

func All() []*Specific {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Specific{}
	}

	ret := make([]*Specific, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建栏目业务流程
func Save(this *Specific) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("新建专题成功！------")
	}

	return id, err
}

//删除栏目业务流程

func Del(n *Specific) error {

	_, err := Specifics().Filter("Id", n.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改栏目业务流程

func Update(n *Specific) error {
	if n.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(n)
	if err == nil {
		fmt.Println("更新专题成功！")
	}
	return err
}

func Specifics() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Specific))
}
