package action

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetActionList(page int64, page_size int64, sort string) (actions []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(Action)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&actions, "Id", "ActionType", "TitleImg", "Name", "Subject", "Content")
	count, _ = qs.Count()
	return actions, count
}

//根据Id获取单个活动
func OneById(id int64) *Action {
	if id <= 0 {
		return nil
	}
	o := Action{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部活动
func AllIdsInDB() []int64 {
	var actions []Action
	Actions().OrderBy("-Id").All(&actions, "Id")
	size := len(actions)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = actions[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*Action {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Action{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*Action, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建活动流程
func Save(this *Action) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存活动信息成功！------")
	}

	return id, err
}

//删除活动流程

func Del(f *Action) error {
	_, err := Actions().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改活动流程

func Update(f *Action) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改活动信息成功！")
	}
	return err
}

func Actions() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Action))
}
