package spelib

import (
	. "cmsgo/models"
	"cmsgo/models/image"
	"cmsgo/models/imggroup"
	"cmsgo/models/news"
	"cmsgo/models/video"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页处理
func GetSpeliblist(page int64, page_size int64, sort string) (spelibs []orm.Params, count int64) {
	o := orm.NewOrm()
	n := new(Spelib)
	qs := o.QueryTable(n)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&spelibs, "Id", "SpecificId", "ItemType", "MetaId", "NodeId", "SiteId", "OrderId")
	count, _ = qs.Count()
	return spelibs, count
}

//返回专题列表

func ApiMetalist(page int64, page_size int64, sort string, SpecificId int64) (metaes []orm.Params, count int64) {
	o := orm.NewOrm()
	p := new(Spelib)
	qs := o.QueryTable(p)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).Filter("SpecificId", SpecificId).OrderBy(sort).Values(&metaes, "Id", "SpecificId", "OrderId", "ItemType", "NodeId", "SiteId", "MetaId")
	count, _ = qs.Count()
	return metaes, count
}

//根据Id和pubType返回对象
func GetSpeById(MetaId int64, pubType int64) interface{} {
	switch pubType {
	//幻灯图片
	//case 1:
	//f := flash.OneById(MetaId)
	//return map[string]interface{}{"flash": &f}
	//return &f
	//单张图片
	case 2:
		i := image.OneById(MetaId)
		//return map[string]interface{}{"image": &i}

		return &i
	//视频
	case 3:
		v := video.OneById(MetaId)
		//return map[string]interface{}{"video": &v}
		return &v
	//普通新闻
	case 4:
		n := news.OneById(MetaId)
		//return map[string]interface{}{"news": &n}
		return &n
	//组图
	case 7:
		imgs := imggroup.OneById(MetaId)
		//return map[string]interface{}{"imggroup": &imgs}
		return &imgs
	default:
		result := "此专题已经被删除！"
		return result
	}

}

func OneById(id int64) *Spelib {
	if id <= 0 {
		return nil
	}
	o := Spelib{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

func AllIdsInDB() []int64 {
	var spelibs []Spelib
	Spelibs().OrderBy("-Id").All(&spelibs, "Id")
	size := len(spelibs)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = spelibs[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

func All() []*Spelib {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Spelib{}
	}

	ret := make([]*Spelib, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

func Save(this *Spelib) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存素材到专题库成功！------")
	}

	return id, err
}

func Del(n *Spelib) error {

	_, err := Spelibs().Filter("Id", n.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

func Update(n *Spelib) error {
	if n.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(n)
	if err == nil {
		fmt.Println("更新专题列表成功！")
	}
	return err
}

func Spelibs() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Spelib))
}
