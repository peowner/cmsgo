package adflashimg

import (
	. "cmsgo/models"
	"fmt"
	"github.com/astaxie/beego/orm"
)

//分页列表

func GetAdFlashImagelist(page int64, page_size int64, sort string) (AdFlashimges []orm.Params, count int64) {
	o := orm.NewOrm()
	i := new(AdFlashImg)
	qs := o.QueryTable(i)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&AdFlashimges, "Id", "NodeId", "Title", "ImgUrl", "ImgText", "PubTime", "Source", "Author", "IsPublish", "Publisher", "ReadCount")
	count, _ = qs.Count()
	return AdFlashimges, count
}

//根据Id获取单个图片
func OneById(id int64) *AdFlashImg {
	if id <= 0 {
		return nil
	}
	o := AdFlashImg{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部图片
func AllIdsInDB() []int64 {
	var adimages []AdFlashImg
	AdFlashImgs().OrderBy("-Id").All(&adimages, "Id")
	size := len(adimages)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = adimages[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*AdFlashImg {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*AdFlashImg{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*AdFlashImg, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建图片业务流程
func Save(this *AdFlashImg) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存图片成功！------")
	}

	return id, err
}

//删除图片业务流程

func Del(f *AdFlashImg) error {
	_, err := AdFlashImgs().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改图片业务流程

func Update(f *AdFlashImg) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改图片成功！")
	}
	return err
}

//发布图片业务流程

func Publish(f *AdFlashImg) error {

	f.IsPublish = 1
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("发布图片成功！")
	}
	return err
}

//撤回图片业务流程

func Revoke(f *AdFlashImg) error {

	f.IsPublish = 0
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("撤回图片成功！")
	}
	return err

}

func AdFlashImgs() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(AdFlashImg))
}
