package publib

import (
	. "cmsgo/models"
	//	"cmsgo/models/flash"
	"cmsgo/models/image"
	"cmsgo/models/imggroup"
	"cmsgo/models/news"
	"cmsgo/models/specific"
	"cmsgo/models/video"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页处理
func GetMetalist(page int64, page_size int64, sort string) (metaes []orm.Params, count int64) {
	o := orm.NewOrm()
	n := new(Publib)
	qs := o.QueryTable(n)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&metaes, "Id", "PubType", "MetaId", "OrderId", "NodeId", "SiteId")
	count, _ = qs.Count()
	return metaes, count
}
func OneById(id int64) *Publib {
	if id <= 0 {
		return nil
	}
	o := Publib{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//api接口查询

//参数为请求的页码

func ApiMetalist(page int64, page_size int64, sort string, nodeId int64) (metaes []orm.Params, count int64) {
	o := orm.NewOrm()
	p := new(Publib)
	qs := o.QueryTable(p)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).Filter("NodeId", nodeId).OrderBy(sort).Values(&metaes, "Id", "PubType", "MetaId", "OrderId", "NodeId", "SiteId")
	count, _ = qs.Count()
	return metaes, count
}

//根据Id和pubType返回对象
func GetNewsById(MetaId int64, pubType int64) interface{} {
	switch pubType {
	//幻灯图片
	//case 1:
	//f := flash.OneById(MetaId)
	//return map[string]interface{}{"flash": &f}
	//return &f
	//单张图片
	case 2:
		i := image.OneById(MetaId)
		//return map[string]interface{}{"image": &i}

		return &i
	//视频
	case 3:
		v := video.OneById(MetaId)
		//return map[string]interface{}{"video": &v}
		return &v
	//普通新闻
	case 4:
		n := news.OneById(MetaId)
		//return map[string]interface{}{"news": &n}
		return &n
	//专题
	case 6:
		s := specific.OneById(MetaId)
		//return map[string]interface{}{"specific": &s}
		return &s
	//组图
	case 7:
		imgs := imggroup.OneById(MetaId)
		//return map[string]interface{}{"imggroup": &imgs}
		return &imgs
	default:
		result := "此稿件已经被删除！"
		return result
	}

}

//发布保存
func Save(this *Publib) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存元数据到发布库成功！------")
	}

	return id, err
}
func Del(n *Publib) error {
	_, err := Publibs().Filter("Id", n.Id).Delete()
	if err != nil {
		return err
	}
	return nil
}
func Update(n *Publib) error {
	if n.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(n)
	if err == nil {
		fmt.Println("修改发布元数据成功！")
	}
	return err
}

func Publibs() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Publib))
}
