package order

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetOrderList(page int64, page_size int64, sort string) (orders []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(Order)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&orders, "Id", "User", "Number", "Address", "Time", "IsDone")
	count, _ = qs.Count()
	return orders, count
}

//根据Id获取单个幻灯图片
func OneById(id int64) *Order {
	if id <= 0 {
		return nil
	}
	o := Order{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部幻灯图片
func AllIdsInDB() []int64 {
	var orders []Order
	Orders().OrderBy("-Id").All(&orders, "Id")
	size := len(orders)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = orders[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*Order {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Order{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*Order, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建订报流程
func Save(this *Order) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存订报信息成功！------")
	}

	return id, err
}

//删除报料流程

func Del(f *Order) error {
	_, err := Orders().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改订报流程

func Update(f *Order) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改订报信息成功！")
	}
	return err
}

func Orders() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Order))
}
