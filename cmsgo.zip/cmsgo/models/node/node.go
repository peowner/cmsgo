package node

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetNodelist(page int64, page_size int64, sort string) (nodes []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(Node)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&nodes, "Id", "NodeName", "OrderId", "IsUsed", "SiteId")
	count, _ = qs.Count()
	return nodes, count
}

//根据Id获取单个频道
func OneById(id int64) *Node {
	if id <= 0 {
		return nil
	}
	o := Node{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//返回所有的频道信息

func AllIdsInDB() []int64 {
	var nodes []Node
	Nodes().OrderBy("OrderId").All(&nodes, "Id")
	size := len(nodes)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = nodes[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

func All() []*Node {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Node{}
	}

	ret := make([]*Node, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建栏目业务流程
func Save(this *Node) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("新建栏目成功！------")
	}

	return id, err
}

//删除栏目业务流程

func Del(n *Node) error {

	if n.IsUsed == 1 {

		return fmt.Errorf("不能删除正在使用的频道！")

	}
	_, err := Nodes().Filter("Id", n.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改栏目业务流程

func Update(n *Node) error {
	if n.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(n)
	if err == nil {
		fmt.Println("修改频道成功！")
	}
	return err
}

func Nodes() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Node))
}
