package push

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页处理
func GetPushlist(page int64, page_size int64, sort string) (pushes []orm.Params, count int64) {
	o := orm.NewOrm()
	n := new(Push)
	qs := o.QueryTable(n)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&pushes, "Id", "Title", "Content", "PubTime", "IsPublish", "Publisher")
	count, _ = qs.Count()
	return pushes, count
}

//根据Id获取单个推送信息
func OneById(id int64) *Push {
	if id <= 0 {
		return nil
	}
	o := Push{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

func AllIdsInDB() []int64 {
	var newses []Push
	Pushes().OrderBy("Id").All(&newses, "Id")
	size := len(newses)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = newses[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

func All() []*Push {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Push{}
	}

	ret := make([]*Push, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

func Save(this *Push) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("新建推送信息成功！------")
	}

	return id, err
}

func Del(n *Push) error {
	_, err := Pushes().Filter("Id", n.Id).Delete()
	if err != nil {
		return err
	}
	return nil
}

func Update(n *Push) error {
	if n.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(n)
	if err == nil {
		fmt.Println("修改推送信息成功！")
	}
	return err
}

func Pushes() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Push))
}
