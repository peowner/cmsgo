package permission

import (
	. "cmsgo/models"
	"errors"
	"github.com/astaxie/beego/orm"
	"github.com/astaxie/beego/validation"
	"log"
)

//验证用户信息
func checkPermission(u *Permission) (err error) {
	valid := validation.Validation{}
	b, _ := valid.Valid(&u)
	if !b {
		for _, err := range valid.Errors {
			log.Println(err.Key, err.Message)
			return errors.New(err.Message)
		}
	}
	return nil
}

//获取权限
func GetPermissionlist(page int64, page_size int64, sort string) (permissions []orm.Params, count int64) {
	o := orm.NewOrm()
	p := new(Permission)
	qs := o.QueryTable(p)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&permissions, "Id", "Title", "Name", "Status", "Pid", "Remark", "Group__id")
	count, _ = qs.Count()
	return permissions, count
}

func ReadPermission(nid int64) (Permission, error) {
	o := orm.NewOrm()
	p := Permission{Id: nid}
	err := o.Read(&p)
	if err != nil {
		return p, err
	}
	return p, nil
}

//添加用户权限
func AddPermission(p *Permission) (int64, error) {
	if err := checkPermission(p); err != nil {
		return 0, err
	}
	o := orm.NewOrm()
	node := new(Permission)
	node.Title = p.Title
	node.Name = p.Name
	node.Level = p.Level
	node.Pid = p.Pid
	node.Remark = p.Remark
	node.Status = p.Status
	node.Group = p.Group

	id, err := o.Insert(node)
	return id, err
}

//更新权限
func UpdatePermission(n *Permission) (int64, error) {
	if err := checkPermission(n); err != nil {
		return 0, err
	}
	o := orm.NewOrm()
	node := make(orm.Params)
	if len(n.Title) > 0 {
		node["Title"] = n.Title
	}
	if len(n.Name) > 0 {
		node["Name"] = n.Name
	}
	if len(n.Remark) > 0 {
		node["Remark"] = n.Remark
	}
	if n.Status != 0 {
		node["Status"] = n.Status
	}
	if len(node) == 0 {
		return 0, errors.New("update field is empty")
	}
	var table Permission
	num, err := o.QueryTable(table).Filter("Id", n.Id).Update(node)
	return num, err
}

func DelPermissionById(Id int64) (int64, error) {
	o := orm.NewOrm()
	status, err := o.Delete(&Permission{Id: Id})
	return status, err
}

func GetPermissionlistByGroupid(Groupid int64) (nodes []orm.Params, count int64) {
	o := orm.NewOrm()
	node := new(Permission)
	count, _ = o.QueryTable(node).Filter("Group", Groupid).RelatedSel().Values(&nodes)
	return nodes, count
}

func GetPermissionTree(pid int64, level int64) ([]orm.Params, error) {
	o := orm.NewOrm()
	node := new(Permission)
	var nodes []orm.Params
	_, err := o.QueryTable(node).Filter("Pid", pid).Filter("Level", level).Filter("Status", 2).Values(&nodes)
	if err != nil {
		return nodes, err
	}
	return nodes, nil
}
