package live

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetLiveList(page int64, page_size int64, sort string) (lives []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(Live)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&lives, "Id", "TitleImg", "Name", "Subject", "HostId", "IsPublish")
	count, _ = qs.Count()
	return lives, count
}

//根据Id获取单个直播
func OneById(id int64) *Live {
	if id <= 0 {
		return nil
	}
	o := Live{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部直播
func AllIdsInDB() []int64 {
	var lives []Live
	Lives().OrderBy("-Id").All(&lives, "Id")
	size := len(lives)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = lives[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*Live {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Live{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*Live, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建直播流程
func Save(this *Live) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存直播信息成功！------")
	}

	return id, err
}

//删除活动流程

func Del(f *Live) error {
	_, err := Lives().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改直播流程

func Update(f *Live) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改直播信息成功！")
	}
	return err
}

func Lives() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Live))
}
