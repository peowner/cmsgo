package about

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetAboutList(page int64, page_size int64, sort string) (abouts []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(About)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&abouts, "Id", "Title", "Content")
	count, _ = qs.Count()
	return abouts, count
}

//根据Id获取单个活动
func OneById(id int64) *About {
	if id <= 0 {
		return nil
	}
	o := About{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部活动
func AllIdsInDB() []int64 {
	var abouts []About
	Abouts().OrderBy("-Id").All(&abouts, "Id")
	size := len(abouts)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = abouts[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*About {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*About{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*About, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建关于我们
func Save(this *About) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存关于我们信息成功！------")
	}

	return id, err
}

//删除关于我们

func Del(f *About) error {
	_, err := Abouts().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改关于我们流程

func Update(f *About) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改关于我们信息成功！")
	}
	return err
}

func Abouts() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(About))
}
