package imagemeta

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表
func GetImgMetaGrouplist(page int64, page_size int64, sort string) (imagemetas []orm.Params, count int64) {
	o := orm.NewOrm()
	i := new(ImageMeta)
	qs := o.QueryTable(i)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&imagemetas, "Id", "Title", "GroupId", "ImgUrl", "ImgText", "PubTime", "Author", "IsPublish", "ReadCount", "Publisher", "Source")
	count, _ = qs.Count()
	return imagemetas, count
}

//根据组图id获取组图中所有单张图片信息

func GetImgsFromGrouplist(GroupId int64) (imagemetas []orm.Params, count int64) {
	o := orm.NewOrm()
	i := new(ImageMeta)
	qs := o.QueryTable(i)
	qs.Filter("GroupId", GroupId).Values(&imagemetas, "Id", "Title", "GroupId", "ImgUrl", "ImgText", "PubTime", "Author", "IsPublish", "ReadCount", "Publisher", "Source")
	count, _ = qs.Count()
	return imagemetas, count
}

//根据Id获取图片组
func OneById(id int64) *ImageMeta {
	if id <= 0 {
		return nil
	}
	o := ImageMeta{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//新建图片业务流程
func Save(this *ImageMeta) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存图片组成功！------")
	}

	return id, err
}

//删除图片业务流程

func Del(f *ImageMeta) error {
	_, err := ImageMetas().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改图片业务流程

func Update(f *ImageMeta) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改图片成功！")
	}
	return err
}

//发布图片业务流程

func Publish(f *ImageMeta) error {
	f.IsPublish = 1
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("发布图片成功！")
	}
	return err
}

//撤回图片业务流程

func Revoke(f *ImageMeta) error {

	f.IsPublish = 0
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("撤回图片组成功！")
	}
	return err

}

func ImageMetas() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(ImageMeta))
}
