//单张图片
package image

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetImagelist(page int64, page_size int64, sort string) (images []orm.Params, count int64) {
	o := orm.NewOrm()
	i := new(Image)
	qs := o.QueryTable(i)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&images, "Id", "Title", "ImgUrl", "ImgText", "PubTime", "Source", "Author", "IsPublish", "Publisher", "ReadCount", "PubType")
	count, _ = qs.Count()
	return images, count
}

//根据Id获取单个图片
func OneById(id int64) *Image {
	if id <= 0 {
		return nil
	}
	o := Image{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部图片
func AllIdsInDB() []int64 {
	var images []Image
	Images().OrderBy("-Id").All(&images, "Id")
	size := len(images)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = images[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*Image {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Image{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*Image, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建图片业务流程
func Save(this *Image) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存图片成功！------")
	}

	return id, err
}

//删除图片业务流程

func Del(f *Image) error {
	_, err := Images().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改图片业务流程

func Update(f *Image) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改图片成功！")
	}
	return err
}

//发布图片业务流程

func Publish(f *Image) error {

	f.IsPublish = 1
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("发布图片成功！")
	}
	return err
}

//撤回图片业务流程

func Revoke(f *Image) error {

	f.IsPublish = 0
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("撤回图片成功！")
	}
	return err

}

func Images() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Image))
}
