package video

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页处理
func GetVideolist(page int64, page_size int64, sort string) (videoes []orm.Params, count int64) {
	o := orm.NewOrm()
	v := new(Video)
	qs := o.QueryTable(v)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&videoes, "Id", "Title", "TitleImg", "VideoUrl", "VideoText", "PubTime", "Source", "Author", "IsPublish", "Publisher", "ReadCount", "PubType")
	count, _ = qs.Count()
	return videoes, count
}

//根据Id获取单个幻灯图片
func OneById(id int64) *Video {
	if id <= 0 {
		return nil
	}
	o := Video{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//获取全部
func AllIdsInDB() []int64 {
	var videoes []Video
	Videoes().OrderBy("-Id").All(&videoes, "Id")
	size := len(videoes)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = videoes[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

//返回10条
func All() []*Video {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Video{}
	}

	if size > 10 {

		size = 10

	}

	ret := make([]*Video, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建业务流程
func Save(this *Video) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("保存视频成功！------")
	}

	return id, err
}

//删除业务流程

func Del(f *Video) error {
	_, err := Videoes().Filter("Id", f.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改流程

func Update(f *Video) error {
	if f.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("修改视频成功！")
	}
	return err
}

//发布业务流程

func Publish(f *Video) error {

	f.IsPublish = 1
	_, err := orm.NewOrm().Update(f)
	if err == nil {
		fmt.Println("发布视频成功！")
	}
	return err
}

//撤回业务流程

func Revoke(v *Video) error {

	v.IsPublish = 0
	_, err := orm.NewOrm().Update(v)
	if err == nil {
		fmt.Println("撤回视频成功！")
	}
	return err

}

func Videoes() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Video))
}
