package models

import (
	"time"

	"github.com/astaxie/beego/orm"
	"github.com/astaxie/beego/validation"
	_ "github.com/go-sql-driver/mysql"
)

//幻灯图片数据结构定义

type Flash struct {
	Id        int64
	Title     string
	ImgUrl    string
	ImgText   string `orm:"type(text)"`
	PubTime   time.Time
	Source    string
	Author    string
	IsPublish int
	Publisher string
	ReadCount int64
}

//幻灯发布库数据结构定义
type FlashPublib struct {
	Id int64

	PubType int

	MetaId int64

	OrderId int64

	NodeId int

	SiteId int
}

//频道数据结构定义

type Node struct {
	Id       int64
	NodeName string
	OrderId  int
	IsUsed   int
	SiteId   int
}

//站点数据结构

type Site struct {
	Id int64

	SiteName string

	IsUsed int
}

//普通新闻数据结构

type News struct {
	Id        int64
	Title     string
	Author    string
	Source    string
	Content   string `orm:"type(text)"`
	Subject   string `orm:"type(text)"`
	PubTime   time.Time
	TitleImg  string
	IsPublish int
	ReadCount int64
	Publisher string
	PubType   int
}

type Push struct {
	Id        int64
	Title     string
	Content   string `orm:"type(text)"`
	PubTime   time.Time
	IsPublish int
	Publisher string
}

//专题

type Specific struct {
	Id           int64
	SpecialTitle string
	SpecialText  string
	IsPublish    int
	PubTime      time.Time
	ReadCount    int
	SiteId       int
	ImgUrl       string
	PubType      int
}

//专题发布列表

//类型定义

//1：flash幻灯图片
//2.image单张图片
//3.video视频
//4.news新闻
//5.ad广告
//6.专题
//7.组图

type Spelib struct {
	Id         int64
	SpecificId int64
	OrderId    int64
	ItemType   int
	MetaId     int64
	SiteId     int
	NodeId     int
}

//视频数据结构
type Video struct {
	Id        int64
	Title     string
	TitleImg  string
	VideoUrl  string
	VideoText string
	PubTime   time.Time
	IsPublish int
	Publisher string
	ReadCount int64
	Author    string
	Source    string
	PubType   int
}

//图片元数据结构,组成3张以上的图片
type ImageMeta struct {
	Id        int64
	GroupId   int64
	Title     string
	ImgUrl    string
	ImgText   string
	PubTime   time.Time
	IsPublish int
	Publisher string
	ReadCount int
	Author    string
	Source    string
}

//组图数据结构
type ImgGroup struct {
	Id        int64
	Total     int
	Title     string
	IsPublish int
	Publisher string
	ReadCount int
	PubTime   time.Time
	PubType   int
}

//单张图片数据结构
type Image struct {
	Id        int64
	Title     string
	ImgUrl    string
	ImgText   string `orm:"type(text)"`
	PubTime   time.Time
	Source    string
	Author    string
	IsPublish int
	Publisher string
	ReadCount int64
	PubType   int
}

//封面广告数据结构
type AdImage struct {
	Id        int64
	Title     string
	ImgUrl    string
	ImgText   string `orm:"type(text)"`
	PubTime   time.Time
	Source    string
	Author    string
	IsPublish int
	Publisher string
	ReadCount int64
}

//内容广告图片数据结构

type AdContentImg struct {
	Id        int64
	Title     string
	ImgUrl    string
	ImgText   string `orm:"type(text)"`
	PubTime   time.Time
	Source    string
	Author    string
	IsPublish int
	Publisher string
	ReadCount int64
	Content   string `orm:"type(text)"`
	Number    string `orm:"type(text)"`
}

//广告图片数据结构，按照栏目id显示在幻灯图最后一张
type AdFlashImg struct {
	Id        int64
	NodeId    int64
	Title     string
	ImgUrl    string
	ImgText   string `orm:"type(text)"`
	PubTime   time.Time
	Source    string
	Author    string
	IsPublish int
	Publisher string
	ReadCount int64
}

//发布库数据结构
type Publib struct {
	Id int64

	PubType int

	MetaId int64

	OrderId int64

	NodeId int

	SiteId int
}

//后台管理数据定义
//用户表
type User struct {
	Id            int64
	Username      string    `orm:"unique;size(32)" form:"Username"  valid:"Required;MaxSize(20);MinSize(6)"`
	Password      string    `orm:"size(32)" form:"Password" valid:"Required;MaxSize(20);MinSize(6)"`
	Repassword    string    `orm:"-" form:"Repassword" valid:"Required"`
	Nickname      string    `orm:"unique;size(32)" form:"Nickname" valid:"Required;MaxSize(20);MinSize(2)"`
	Email         string    `orm:"size(32)" form:"Email" valid:"Email"`
	Remark        string    `orm:"null;size(200)" form:"Remark" valid:"MaxSize(200)"`
	Status        int       `orm:"default(2)" form:"Status" valid:"Range(1,2)"`
	Lastlogintime time.Time `orm:"null;type(datetime)" form:"-"`
	Createtime    time.Time `orm:"type(datetime);auto_now_add" `
	Role          []*Role   `orm:"rel(m2m)"`
	SiteId        int
}

func (u *User) Valid(v *validation.Validation) {
	if u.Password != u.Repassword {
		v.SetError("Repassword", "两次输入的密码不一样")
	}
}

//权限表
type Permission struct {
	Id     int64
	Title  string  `orm:"size(100)" form:"Title"  valid:"Required"`
	Name   string  `orm:"size(100)" form:"Name"  valid:"Required"`
	Level  int     `orm:"default(1)" form:"Level"  valid:"Required"`
	Pid    int64   `form:"Pid"  valid:"Required"`
	Remark string  `orm:"null;size(200)" form:"Remark" valid:"MaxSize(200)"`
	Status int     `orm:"default(2)" form:"Status" valid:"Range(1,2)"`
	Group  *Group  `orm:"rel(fk)"`
	Role   []*Role `orm:"rel(m2m)"`
}

//角色表
type Role struct {
	Id         int64
	Title      string        `orm:"size(100)" form:"Title"  valid:"Required"`
	Name       string        `orm:"size(100)" form:"Name"  valid:"Required"`
	Remark     string        `orm:"null;size(200)" form:"Remark" valid:"MaxSize(200)"`
	Status     int           `orm:"default(2)" form:"Status" valid:"Range(1,2)"`
	Permission []*Permission `orm:"reverse(many)"`
	User       []*User       `orm:"reverse(many)"`
}

//分组表
type Group struct {
	Id         int64
	Name       string        `orm:"size(100)" form:"Name"  valid:"Required"`
	Title      string        `orm:"size(100)" form:"Title"  valid:"Required"`
	Status     int           `orm:"default(2)" form:"Status" valid:"Range(1,2)"`
	Sort       int           `orm:"default(1)" form:"Sort" valid:"Numeric"`
	Permission []*Permission `orm:"reverse(many)"`
}

//应用管理数据结构
type Application struct {
	Id      int64
	Type    int
	Name    string
	Icon    string
	Waptype int
	Sort    int
	Url     string
}

//报料数据结构定义
type Report struct {
	Id       int64
	Username string
	Image    string
	Number   string
	IsDone   int
	Content  string
}

//订报数据结构定义
type Order struct {
	Id      int64
	User    string
	Number  string
	Address string
	Time    string
	IsDone  int
}

//砸金蛋数据结构
type Egg struct {
	Id    int64
	Prize string
	value int
}

//刮刮卡数据结构定义
type Card struct {
	Id         int64
	KeyWord    string
	ActionName string
	AwardInfo  string
	Notice     string
	ActionImg  string
	StartTime  time.Time
	EndTime    time.Time
	ActionDes  string
	ActionEnd  string
}

//刮刮卡奖项
type CardPrize struct {
	Id             int64
	CardId         int64
	OnePrize       string
	OneNum         int
	TwoPrize       string
	TwoNum         int
	ThreePrize     string
	ThreeNum       int
	PermitNum      int
	ExchangePasswd string
}

//意见反馈数据结构

type Suggestion struct {
	Id int64

	Number string

	Content string

	IsDone int
}

//活动数据结构定义
type Action struct {
	Id         int64
	ActionType int
	TitleImg   string
	Name       string
	Subject    string `orm:"type(text)"`
	Content    string `orm:"type(text)"`
}

//直播数据结构
type Live struct {
	Id        int64
	Name      string
	TitleImg  string
	Subject   string
	LiveType  int
	HostId    int64
	IsPublish int
}

//直播内容数据结构
type LiveContent struct {
	Id       int64
	LiveId   int64
	LiveText string
	ImgUrl   string
	VideoUrl string
	AudioUrl string
	PubTime  time.Time
}

//直播主持人数据结构
type Host struct {
	Id       int64
	HostName string
	LoginId  string
	HostPw   string
	HostImg  string
}

//关于我们数据结构
type About struct {
	Id int64

	Title string

	Content string
}

func engine() string {
	return "INNODB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci"
}

func init() {

	//orm.Debug = true

	orm.RegisterModel(new(Flash), new(Node), new(Site), new(News),
		new(Specific), new(Spelib), new(Video), new(Image), new(ImgGroup),
		new(Publib), new(ImageMeta), new(FlashPublib), new(Permission),
		new(Group), new(Role), new(User), new(AdImage), new(Push), new(AdContentImg), new(AdFlashImg),
		new(Application), new(Report), new(About), new(Order), new(Live), new(LiveContent), new(Host), new(Action), new(Card), new(CardPrize), new(Suggestion))

	orm.RegisterDataBase("default", "mysql", "root:F0under0931@tcp(127.0.0.1:3306)/cmsgo?charset=utf8", 30)
}
