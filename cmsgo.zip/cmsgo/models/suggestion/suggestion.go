package suggestion

import (
	. "cmsgo/models"
	"fmt"

	"github.com/astaxie/beego/orm"
)

//分页列表

func GetSuggestionList(page int64, page_size int64, sort string) (suggestions []orm.Params, count int64) {
	o := orm.NewOrm()
	f := new(Suggestion)
	qs := o.QueryTable(f)
	var offset int64
	if page <= 1 {
		offset = 0
	} else {
		offset = (page - 1) * page_size
	}
	qs.Limit(page_size, offset).OrderBy(sort).Values(&suggestions, "Id", "Number", "Content", "IsDone")
	count, _ = qs.Count()
	return suggestions, count
}

//根据Id获取单个建议
func OneById(id int64) *Suggestion {
	if id <= 0 {
		return nil
	}
	o := Suggestion{Id: id}
	err := orm.NewOrm().Read(&o, "Id")
	if err != nil {
		return nil
	}
	return &o
}

//返回所有的站点信息

func AllIdsInDB() []int64 {
	var suggestions []Suggestion
	Suggestions().OrderBy("Id").All(&suggestions, "Id")
	size := len(suggestions)
	if size == 0 {
		return []int64{}
	}

	ret := make([]int64, size)
	for i := 0; i < size; i++ {
		ret[i] = suggestions[i].Id
	}

	return ret
}

func AllIds() []int64 {
	if ids := AllIdsInDB(); len(ids) != 0 {
		return ids
	} else {
		return []int64{}
	}
}

func All() []*Suggestion {
	ids := AllIds()
	size := len(ids)
	if size == 0 {
		return []*Suggestion{}
	}

	ret := make([]*Suggestion, size)
	for i := 0; i < size; i++ {
		ret[i] = OneById(ids[i])
	}
	return ret
}

//新建建议业务流程
func Save(this *Suggestion) (int64, error) {
	or := orm.NewOrm()
	id, err := or.Insert(this)
	if err == nil {
		fmt.Println("新建建议成功！------")
	}

	return id, err
}

//删除建议业务流程

func Del(s *Suggestion) error {

	if s.IsDone == 1 {

		return fmt.Errorf("不能删除已经处理的建议反馈！")

	}
	_, err := Suggestions().Filter("Id", s.Id).Delete()
	if err != nil {
		return err
	}

	return nil
}

//修改建议

func Update(s *Suggestion) error {
	if s.Id == 0 {
		return fmt.Errorf("primary key:id not set")
	}
	_, err := orm.NewOrm().Update(s)
	if err == nil {
		fmt.Println("修改建议成功！")
	}
	return err
}

func Suggestions() orm.QuerySeter {
	return orm.NewOrm().QueryTable(new(Suggestion))
}
